use crate::error::{LiveError, Result};
use crate::util::{atomic_write, expand_home, home_dir};
use serde::{Deserialize, Serialize};
use std::env;
use std::net::{IpAddr, SocketAddr};
use std::path::{Path, PathBuf};

const CURRENT_SCHEMA_VERSION: u32 = 2;
pub const DEFAULT_CLUSTER_ENDPOINT: &str = "http://127.0.0.1:11435";
/// Oldest `schema_version` this build can read and upgrade in place.
/// Anything older is refused rather than guessed at.
const MINIMUM_SUPPORTED_SCHEMA_VERSION: u32 = 1;

/// A key removed from the schema, and the `schema_version` that removed it.
#[derive(Debug, Clone, Copy)]
struct RetiredKey {
    /// Dotted path to the key, such as `server.max_rpc_bytes`. A path with no
    /// dot names a whole top-level table.
    path: &'static str,
    /// First `schema_version` that no longer accepts the key.
    removed_in: u32,
}

/// Keys this build no longer accepts.
///
/// `deny_unknown_fields` is kept deliberately, so a file still carrying a
/// removed key would otherwise be refused outright. Removing a field therefore
/// means bumping `CURRENT_SCHEMA_VERSION` and listing the field here: files
/// written before the bump keep starting, and the key is dropped as part of the
/// upgrade. An entry can go once `MINIMUM_SUPPORTED_SCHEMA_VERSION` has passed
/// its `removed_in`, because no readable file can contain it any more.
const RETIRED_KEYS: &[RetiredKey] = &[];

/// Drops retired keys from a parsed configuration, returning the paths removed.
///
/// Only keys retired *after* `from` are considered. A file already at the
/// current version is left untouched, so an unrecognised key there stays a hard
/// error rather than being silently discarded as a typo.
fn prune_retired_keys(table: &mut toml::Table, from: u32, retired: &[RetiredKey]) -> Vec<String> {
    let mut dropped = Vec::new();
    for key in retired.iter().filter(|key| key.removed_in > from) {
        if remove_dotted(table, key.path) {
            dropped.push(key.path.to_owned());
        }
    }
    dropped
}

/// Removes a dotted path, reporting whether anything was there.
fn remove_dotted(table: &mut toml::Table, path: &str) -> bool {
    match path.split_once('.') {
        None => table.remove(path).is_some(),
        Some((head, rest)) => table
            .get_mut(head)
            .and_then(toml::Value::as_table_mut)
            .is_some_and(|inner| remove_dotted(inner, rest)),
    }
}

#[derive(Debug, Clone, Copy, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ServerRole {
    #[default]
    Node,
    ControlPlane,
}

impl ServerRole {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Node => "node",
            Self::ControlPlane => "control_plane",
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum TargetPreference {
    Local,
    Remote,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AppConfig {
    pub schema_version: u32,
    #[serde(default)]
    pub role: ServerRole,
    #[serde(default)]
    pub paths: PathsConfig,
    #[serde(default)]
    pub server: ServerConfig,
    #[serde(default)]
    pub client: ClientConfig,
    #[serde(default)]
    pub auth: AuthConfig,
    #[serde(default)]
    pub tracing: TracingConfig,
    #[serde(default)]
    pub telemetry: TelemetryConfig,
    #[serde(default)]
    pub modules: ModulesConfig,
    #[serde(default)]
    pub update: UpdateConfig,
    #[serde(default)]
    pub inference: InferenceConfig,
    #[serde(default)]
    pub holo: HoloConfig,
    #[serde(default)]
    pub plugins: PluginsConfig,
    #[serde(default)]
    pub registry: RegistryConfig,
    #[serde(default)]
    pub cluster: ClusterConfig,
    /// Started from a registry configuration (`registry serve config.yml`):
    /// the public listener carries only `/v2/` and the public system pages,
    /// and administration moves to [`AppConfig::admin_socket`] (ADR 028).
    /// Never read from a file: only `serve --registry-config` sets it.
    #[serde(skip)]
    pub registry_mode: bool,
    /// `http.tls` of a registry configuration: the public listener serves
    /// TLS. Never read from a file: only `serve --registry-config` sets it.
    #[cfg(feature = "oci")]
    #[serde(skip)]
    pub tls: Option<crate::tls::TlsSettings>,
}

/// Seed-based Hologram server membership.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ClusterConfig {
    pub advertise_endpoint: Option<String>,
    pub seeds: Vec<String>,
    pub token_env: String,
    pub heartbeat_interval_secs: u64,
    pub request_timeout_secs: u64,
    pub node_ttl_secs: u64,
    pub max_peers: usize,
    /// Peers contacted per heartbeat round; the cursor rotates so every peer
    /// eventually gets a turn even when the table exceeds this count.
    pub fanout: usize,
    /// Maximum immutable objects fetched from one peer per heartbeat round.
    pub replication_max_objects_per_round: usize,
    /// Maximum bytes accepted for one immutable object transfer.
    pub replication_max_object_bytes: u64,
    /// How often immutable-object anti-entropy runs against a contacted
    /// peer, decoupled from `heartbeat_interval_secs` so that membership
    /// heartbeats stay cheap while every node need not re-walk every peer's
    /// full object inventory on every heartbeat tick.
    pub replication_interval_secs: u64,
    /// Identities always eligible to participate, as `ed25519:<64 hex>`.
    pub trusted_keys: Vec<String>,
    /// `token` pins a new identity on first contact with a valid ticket;
    /// `allowlist` admits only `trusted_keys`.
    ///
    /// **Operator constraint, not something a node can check for itself:**
    /// under `"allowlist"`, every member's `trusted_keys` must list the same
    /// identities. Every node trusts itself for ownership purposes (nothing
    /// authenticates a node to itself), so an *asymmetric* allowlist — one
    /// node's `trusted_keys` omitting a peer that peer's own list includes —
    /// fails open rather than closed: the node with the narrower list simply
    /// names *some other candidate its own list admits* — itself, if no
    /// other admitted node wins the rendezvous hash, but not necessarily —
    /// for resources the wider-list peer would have assigned elsewhere, with
    /// no error and no local signal that the two views disagree. Keep every
    /// member's `trusted_keys` identical.
    pub admission: String,
    /// Which cluster transports this node speaks: `http` (the default),
    /// `iroh`, or `both`. The iroh forms require the `p2p` build feature.
    pub transport: String,
    /// Peer discovery for the iroh transport: `none` (the default), `mdns`,
    /// or `dns`. Publication is a separate decision from enabling the
    /// transport, so the operator-cluster default publishes nothing.
    pub discovery: String,
    /// Relay URLs for the iroh transport. Empty (the default) disables
    /// relaying; self-hosted relays belong here.
    pub relays: Vec<String>,
}

impl Default for ClusterConfig {
    fn default() -> Self {
        Self {
            advertise_endpoint: Some(DEFAULT_CLUSTER_ENDPOINT.to_owned()),
            seeds: Vec::new(),
            token_env: "HOLOGRAM_CLUSTER_TOKEN".to_owned(),
            heartbeat_interval_secs: 15,
            request_timeout_secs: 5,
            node_ttl_secs: 60,
            max_peers: 64,
            fanout: 8,
            replication_max_objects_per_round: 1_000,
            replication_max_object_bytes: 512 * 1024 * 1024,
            replication_interval_secs: 60,
            trusted_keys: Vec::new(),
            admission: "token".to_owned(),
            transport: "http".to_owned(),
            discovery: "none".to_owned(),
            relays: Vec::new(),
        }
    }
}

/// Selects which `RegistryProvider` backs object storage.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct RegistryConfig {
    /// `"local"` or `"kappa"`. Local is the default so a stock install needs
    /// no external service.
    pub provider: String,
    /// Base URL of the kappa-registry instance. Required when
    /// `provider = "kappa"`.
    pub endpoint: String,
    /// Namespace that objects are written under.
    pub namespace: String,
    /// The credential. `user:password` logs in with HTTP Basic, as a
    /// registry behind a password file expects; anything else is sent as a
    /// bearer token. An external registry may allow anonymous access, so an
    /// empty value is valid.
    pub token: String,
    /// How blobs are written: `"standard"` is the registry route every
    /// registry has (`POST /v2/<repo>/blobs/uploads/?digest=…`); `"direct"`
    /// is kappa-registry's own `PUT /v2/<repo>/blobs/<digest>`, which the
    /// distribution API does not define (plan P8 T5, FR-022).
    #[serde(default = "default_upload_flow")]
    pub upload_flow: String,
    pub request_timeout_secs: u64,
    /// Upper bound on remote pages walked to satisfy one selective query.
    /// Reaching it sets `ObjectPage::truncated` rather than silently capping.
    pub max_scan_pages: u32,
}

/// Standard: the route every registry has.
fn default_upload_flow() -> String {
    "standard".to_owned()
}

impl Default for RegistryConfig {
    fn default() -> Self {
        Self {
            provider: "local".to_owned(),
            endpoint: "http://127.0.0.1:5000".to_owned(),
            namespace: "hologram".to_owned(),
            token: String::new(),
            request_timeout_secs: 30,
            upload_flow: default_upload_flow(),
            max_scan_pages: 20,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct PathsConfig {
    pub config_dir: PathBuf,
    pub data_dir: PathBuf,
    pub state_dir: PathBuf,
    pub cache_dir: PathBuf,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ServerConfig {
    pub listen: String,
    pub max_rpc_bytes: usize,
    pub max_http_body_bytes: usize,
    pub graceful_shutdown_secs: u64,
    pub actor_mailbox_capacity: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ClientConfig {
    pub preference: TargetPreference,
    pub local_endpoint: String,
    pub remote_endpoint: Option<String>,
    pub allow_read_fallback: bool,
    pub request_timeout_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct AuthConfig {
    pub required: bool,
    pub token_env: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct TracingConfig {
    pub filter: String,
    pub format: String,
    pub include_target: bool,
    pub include_thread_ids: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct TelemetryConfig {
    /// Enables creation of application metrics and trace context.
    pub enabled: bool,
    /// OTLP/gRPC collector endpoint. No data leaves the process when unset.
    pub endpoint: Option<String>,
    pub service_name: String,
    pub export_timeout_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ModulesConfig {
    pub enabled: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct UpdateConfig {
    pub manifest_url: Option<String>,
    pub channel: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct InferenceConfig {
    /// echo | weightc | ollama | llamacpp | candle | burn | vllm
    pub engine: String,
    /// Imported model id (weightc) or upstream model name (Ollama/vLLM).
    pub default_model: String,
    pub weightc_path: String,
    pub ollama_endpoint: String,
    pub vllm_endpoint: String,
    pub vllm_token_env: String,
    /// Local weights file used by feature-gated in-process engines: GGUF for
    /// llama.cpp/Candle, or a Burn named-MPK checkpoint.
    pub model_path: String,
    /// Tokenizer used by in-process Rust engines. Candle expects tokenizer.json;
    /// Burn expects the Llama 3 tokenizer.model BPE file.
    pub tokenizer_path: String,
    /// Concrete model implementation selected by engines that cannot infer it
    /// from the checkpoint. Candle currently accepts `llama`; Burn accepts
    /// `llama3.2-1b`, `llama3.2-3b`, `llama3.1-8b`, or `llama3-8b`.
    pub model_architecture: String,
    pub n_ctx: u32,
    pub n_gpu_layers: u32,
    /// Maximum number of in-process llama.cpp contexts decoding at once.
    pub llamacpp_max_concurrent_requests: usize,
    pub request_timeout_secs: u64,
    /// Keep `weightc enter --jsonl` sessions resident per conversation.
    /// Only meaningful for the weightc engine.
    pub resident_sessions: bool,
    /// Maximum concurrently resident weightc sessions; the least recently
    /// used session is evicted beyond this bound.
    pub max_resident_sessions: usize,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct HoloConfig {
    /// Explicit development-only effective grant for resident applications.
    /// Relative paths resolve from `paths.config_dir`.
    pub development_grant: Option<PathBuf>,
    /// Archives the service loads into resident sessions during startup,
    /// so declared applications are invocable immediately after boot or
    /// restart without an explicit `holo load`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub resident: Vec<HoloResidentConfig>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HoloResidentConfig {
    /// Content κ (`blake3:` + 64 hex) of an archive already imported into
    /// the local catalog. Load failures are logged and skip only the
    /// failing entry; they do not stop the service from starting.
    pub kappa: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct PluginsConfig {
    /// Master switch for subprocess plugin modules. Defaults to off.
    pub enabled: bool,
    /// Explicit allowlist of plugin executables. There is no directory
    /// scanning: only entries listed here with a pinned sha256 are spawned.
    pub modules: Vec<PluginModuleConfig>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PluginModuleConfig {
    /// Stable module id the plugin must declare in its `Describe` handshake.
    /// Must not collide with a builtin module id.
    pub id: String,
    /// Executable spawned by the daemon. No shell is involved.
    pub path: PathBuf,
    /// Lowercase hex sha256 of the executable, verified before every spawn.
    pub sha256: String,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            schema_version: CURRENT_SCHEMA_VERSION,
            role: ServerRole::Node,
            paths: PathsConfig::default(),
            server: ServerConfig::default(),
            client: ClientConfig::default(),
            auth: AuthConfig::default(),
            tracing: TracingConfig::default(),
            telemetry: TelemetryConfig::default(),
            modules: ModulesConfig::default(),
            update: UpdateConfig::default(),
            inference: InferenceConfig::default(),
            holo: HoloConfig::default(),
            plugins: PluginsConfig::default(),
            registry: RegistryConfig::default(),
            cluster: ClusterConfig::default(),
            registry_mode: false,
            #[cfg(feature = "oci")]
            tls: None,
        }
    }
}

impl Default for PathsConfig {
    fn default() -> Self {
        let home = home_dir();
        Self {
            config_dir: home.join(".config/hologram"),
            data_dir: home.join(".local/share/hologram"),
            state_dir: home.join(".local/state/hologram"),
            cache_dir: home.join(".cache/hologram"),
        }
    }
}

impl Default for ServerConfig {
    fn default() -> Self {
        Self {
            listen: "127.0.0.1:11435".to_owned(),
            max_rpc_bytes: 32 * 1024 * 1024,
            max_http_body_bytes: 32 * 1024 * 1024,
            graceful_shutdown_secs: 30,
            actor_mailbox_capacity: 128,
        }
    }
}

impl Default for ClientConfig {
    fn default() -> Self {
        Self {
            preference: TargetPreference::Local,
            local_endpoint: "http://127.0.0.1:11435".to_owned(),
            remote_endpoint: None,
            allow_read_fallback: true,
            request_timeout_secs: 30,
        }
    }
}

impl Default for AuthConfig {
    fn default() -> Self {
        Self {
            required: false,
            token_env: "HOLOGRAM_AUTH_TOKEN".to_owned(),
        }
    }
}

impl Default for TracingConfig {
    fn default() -> Self {
        Self {
            filter: "info,hologram_live=debug".to_owned(),
            format: "pretty".to_owned(),
            include_target: true,
            include_thread_ids: false,
        }
    }
}

impl Default for TelemetryConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            endpoint: None,
            service_name: "hologram-live".to_owned(),
            export_timeout_secs: 5,
        }
    }
}

impl Default for ModulesConfig {
    fn default() -> Self {
        Self {
            enabled: crate::modules::default_builtin_ids(),
        }
    }
}

impl Default for UpdateConfig {
    fn default() -> Self {
        Self {
            manifest_url: None,
            channel: "stable".to_owned(),
        }
    }
}

impl Default for InferenceConfig {
    fn default() -> Self {
        Self {
            engine: "echo".to_owned(),
            default_model: String::new(),
            weightc_path: "weightc".to_owned(),
            ollama_endpoint: "http://127.0.0.1:11434".to_owned(),
            vllm_endpoint: "http://127.0.0.1:8000".to_owned(),
            vllm_token_env: "VLLM_API_KEY".to_owned(),
            model_path: String::new(),
            tokenizer_path: String::new(),
            model_architecture: String::new(),
            n_ctx: 4096,
            n_gpu_layers: 0,
            llamacpp_max_concurrent_requests: 1,
            request_timeout_secs: 300,
            resident_sessions: false,
            max_resident_sessions: 4,
        }
    }
}

impl AppConfig {
    pub fn default_path() -> PathBuf {
        env::var_os("HOLOGRAM_CONFIG_DIR")
            .map_or_else(|| home_dir().join(".config/hologram"), PathBuf::from)
            .join("live.toml")
    }

    pub fn initialize(path: Option<&Path>, force: bool) -> Result<PathBuf> {
        let path = path.map_or_else(Self::default_path, expand_home);
        if path.exists() && !force {
            return Err(LiveError::Conflict(format!(
                "{} already exists; pass --force to replace it",
                path.display()
            )));
        }
        let config = Self::default();
        config.create_directories()?;
        let bytes = toml::to_string_pretty(&config)?;
        atomic_write(&path, bytes.as_bytes())?;
        Ok(path)
    }

    /// Loads the configuration, upgrading an older `schema_version` in place.
    pub fn load(path: Option<&Path>) -> Result<(Self, PathBuf)> {
        Self::load_inner(path, true)
    }

    /// Loads the configuration without upgrading it.
    ///
    /// Tracing is configured *from* the configuration, so the first read
    /// happens before a subscriber exists. Upgrading there would rewrite the
    /// file and drop the log line describing it. This read leaves the file
    /// alone and lets the first post-subscriber `load` perform and report the
    /// upgrade; an out-of-date file simply fails `validate` here, and the
    /// caller falls back to defaults for tracing.
    pub fn load_for_bootstrap(path: Option<&Path>) -> Result<(Self, PathBuf)> {
        Self::load_inner(path, false)
    }

    fn load_inner(path: Option<&Path>, upgrade: bool) -> Result<(Self, PathBuf)> {
        let path = path.map_or_else(Self::default_path, expand_home);
        let exists = path.exists();
        let mut config = if exists {
            let source =
                std::fs::read_to_string(&path).map_err(|error| LiveError::io(&path, error))?;
            Self::from_source(&source, upgrade, &path, RETIRED_KEYS)?
        } else {
            Self::default()
        };
        if upgrade {
            let from = config.schema_version;
            // Persist before environment overrides and `~` expansion are
            // applied, so only what the user actually wrote goes back to disk.
            if config.migrate()? && exists {
                config.persist_upgrade(&path, from);
            }
        }
        config.apply_environment()?;
        config.expand_paths();
        config.validate()?;
        Ok((config, path))
    }

    /// Parses a configuration file, dropping keys retired by a newer schema.
    ///
    /// The prune has to happen on the raw table: `deny_unknown_fields` rejects a
    /// retired key during deserialisation, before `schema_version` is ever read,
    /// so the upgrade path in `migrate` would never be reached.
    fn from_source(
        source: &str,
        upgrade: bool,
        path: &Path,
        retired: &[RetiredKey],
    ) -> Result<Self> {
        if !upgrade {
            return Ok(toml::from_str::<Self>(source)?);
        }
        let mut table = toml::from_str::<toml::Table>(source)?;
        // A file with no readable version is left alone; deserialisation below
        // reports the missing or malformed field.
        if let Some(from) = table
            .get("schema_version")
            .and_then(toml::Value::as_integer)
            .and_then(|version| u32::try_from(version).ok())
        {
            let dropped = prune_retired_keys(&mut table, from, retired);
            if !dropped.is_empty() {
                tracing::warn!(
                    config.path = %path.display(),
                    config.schema_from = from,
                    config.dropped_keys = %dropped.join(", "),
                    "dropped configuration keys retired by a newer schema"
                );
            }
        }
        Ok(toml::Value::Table(table).try_into::<Self>()?)
    }

    /// Brings a parsed configuration up to `CURRENT_SCHEMA_VERSION`, reporting
    /// whether anything changed.
    ///
    /// Schema growth has been additive, and missing fields already fall back to
    /// their defaults during deserialisation, so an upgrade is a version
    /// restamp rather than a field-by-field transform. Should a future version
    /// need to *move* or reinterpret a value, this is where that step belongs.
    fn migrate(&mut self) -> Result<bool> {
        if self.schema_version == CURRENT_SCHEMA_VERSION {
            return Ok(false);
        }
        // A newer file may carry settings this build would drop on write, so
        // refuse rather than silently downgrade it.
        if self.schema_version > CURRENT_SCHEMA_VERSION {
            return Err(LiveError::Config(format!(
                "configuration schema {} is newer than this build supports ({CURRENT_SCHEMA_VERSION}); upgrade hologram to read it",
                self.schema_version
            )));
        }
        if self.schema_version < MINIMUM_SUPPORTED_SCHEMA_VERSION {
            return Err(LiveError::Config(format!(
                "configuration schema {} predates the oldest readable schema ({MINIMUM_SUPPORTED_SCHEMA_VERSION}); regenerate it with `hologram init --force`",
                self.schema_version
            )));
        }
        self.schema_version = CURRENT_SCHEMA_VERSION;
        Ok(true)
    }

    /// Writes an upgraded configuration back so the next start reads a current
    /// file.
    fn persist_upgrade(&self, path: &Path, from: u32) {
        let written = toml::to_string_pretty(self)
            .map_err(LiveError::from)
            .and_then(|encoded| atomic_write(path, encoded.as_bytes()));
        match written {
            Ok(()) => tracing::info!(
                config.path = %path.display(),
                config.schema_from = from,
                config.schema_to = CURRENT_SCHEMA_VERSION,
                "upgraded configuration schema"
            ),
            // An unwritable config directory must not stop the daemon: the
            // configuration in hand is already current, only the file lags.
            Err(error) => tracing::warn!(
                config.path = %path.display(),
                config.schema_from = from,
                error = %error,
                "configuration upgraded in memory but could not be written back"
            ),
        }
    }

    pub fn create_directories(&self) -> Result<()> {
        for path in [
            &self.paths.config_dir,
            &self.paths.data_dir,
            &self.paths.state_dir,
            &self.paths.cache_dir,
        ] {
            std::fs::create_dir_all(path).map_err(|error| LiveError::io(path, error))?;
        }
        Ok(())
    }

    pub fn validate(&self) -> Result<()> {
        if self.schema_version != CURRENT_SCHEMA_VERSION {
            return Err(LiveError::Config(format!(
                "unsupported configuration schema {}",
                self.schema_version
            )));
        }
        let listen: SocketAddr = self
            .server
            .listen
            .parse()
            .map_err(|error| LiveError::Config(format!("invalid server.listen: {error}")))?;
        if self.registry_mode {
            // A public anonymous registry, as the reference is by default:
            // the public listener carries nothing but /v2/ and the public
            // system pages, so the rules below have nothing left to guard.
            self.validate_registry_mode()?;
        } else if !is_loopback(listen.ip()) && !self.auth.required {
            return Err(LiveError::Config(
                "non-loopback server.listen requires auth.required = true".to_owned(),
            ));
        }
        // The registry answers /v2/ without the bearer token (ADR 026), and has
        // no login of its own yet. auth.required does not cover it, so it must
        // not face a network until it does.
        #[cfg(feature = "oci")]
        if !is_loopback(listen.ip())
            && !self.registry_mode
            && self
                .modules
                .enabled
                .iter()
                .any(|id| id == crate::modules::oci::MODULE_ID)
        {
            return Err(LiveError::Config(format!(
                "{} has no login yet and requires a loopback server.listen",
                crate::modules::oci::MODULE_ID
            )));
        }
        if self.holo.development_grant.is_some() && !is_loopback(listen.ip()) {
            return Err(LiveError::Config(
                "holo.development_grant is development-only and requires a loopback server.listen"
                    .to_owned(),
            ));
        }
        if self.server.max_rpc_bytes == 0 || self.server.max_http_body_bytes == 0 {
            return Err(LiveError::Config(
                "message and body limits must be greater than zero".to_owned(),
            ));
        }
        if self.server.actor_mailbox_capacity == 0 {
            return Err(LiveError::Config(
                "server.actor_mailbox_capacity must be greater than zero".to_owned(),
            ));
        }
        if self.auth.required && env::var_os(&self.auth.token_env).is_none() {
            return Err(LiveError::Config(format!(
                "auth.required is true but {} is not set",
                self.auth.token_env
            )));
        }
        validate_endpoint(&self.client.local_endpoint, true)?;
        if let Some(remote) = &self.client.remote_endpoint {
            validate_endpoint(remote, false)?;
        }
        match self.tracing.format.as_str() {
            "pretty" | "compact" | "json" => {}
            other => {
                return Err(LiveError::Config(format!(
                    "unsupported tracing.format {other:?}"
                )))
            }
        }
        if let Some(endpoint) = &self.telemetry.endpoint {
            validate_endpoint(endpoint, false)?;
        }
        match self.inference.engine.as_str() {
            "echo" | "weightc" | "ollama" | "vllm" => {}
            "llamacpp" => {
                if !cfg!(feature = "llamacpp") {
                    return Err(LiveError::Config(
                        "inference.engine \"llamacpp\" needs a build with --features llamacpp"
                            .to_owned(),
                    ));
                }
                if self.inference.model_path.trim().is_empty()
                    && self.inference.default_model.trim().is_empty()
                {
                    return Err(LiveError::Config(
                        "llamacpp requires inference.model_path or an imported inference.default_model"
                            .to_owned(),
                    ));
                }
            }
            "candle" => {
                validate_compiled_local_engine(
                    cfg!(feature = "candle"),
                    "candle",
                    &self.inference,
                    true,
                )?;
                if !matches!(self.inference.model_architecture.as_str(), "llama") {
                    return Err(LiveError::Config(
                        "candle currently requires inference.model_architecture = \"llama\""
                            .to_owned(),
                    ));
                }
            }
            "burn" => {
                validate_compiled_local_engine(
                    cfg!(feature = "burn"),
                    "burn",
                    &self.inference,
                    false,
                )?;
                if !matches!(
                    self.inference.model_architecture.as_str(),
                    "llama3.2-1b" | "llama3.2-3b" | "llama3.1-8b" | "llama3-8b"
                ) {
                    return Err(LiveError::Config(
                        "burn inference.model_architecture must be llama3.2-1b, llama3.2-3b, llama3.1-8b, or llama3-8b"
                            .to_owned(),
                    ));
                }
            }
            other => {
                return Err(LiveError::Config(format!(
                    "unsupported inference.engine {other:?}; expected echo, weightc, ollama, llamacpp, candle, burn, or vllm"
                )))
            }
        }
        if self.inference.weightc_path.trim().is_empty() {
            return Err(LiveError::Config(
                "inference.weightc_path must not be empty".to_owned(),
            ));
        }
        validate_endpoint(&self.inference.ollama_endpoint, false)?;
        validate_endpoint(&self.inference.vllm_endpoint, false)?;
        if self.inference.vllm_token_env.trim().is_empty() {
            return Err(LiveError::Config(
                "inference.vllm_token_env must not be empty".to_owned(),
            ));
        }
        if self.inference.n_ctx == 0 {
            return Err(LiveError::Config(
                "inference.n_ctx must be greater than zero".to_owned(),
            ));
        }
        if self.inference.llamacpp_max_concurrent_requests == 0 {
            return Err(LiveError::Config(
                "inference.llamacpp_max_concurrent_requests must be greater than zero".to_owned(),
            ));
        }
        if self.inference.request_timeout_secs == 0 {
            return Err(LiveError::Config(
                "inference.request_timeout_secs must be greater than zero".to_owned(),
            ));
        }
        if self.inference.max_resident_sessions == 0 {
            return Err(LiveError::Config(
                "inference.max_resident_sessions must be greater than zero".to_owned(),
            ));
        }
        if self.telemetry.service_name.trim().is_empty() {
            return Err(LiveError::Config(
                "telemetry.service_name must not be empty".to_owned(),
            ));
        }
        if self.telemetry.export_timeout_secs == 0 {
            return Err(LiveError::Config(
                "telemetry.export_timeout_secs must be greater than zero".to_owned(),
            ));
        }
        self.validate_holo_resident()?;
        self.validate_plugins()?;
        self.validate_registry()?;
        self.validate_cluster()?;
        Ok(())
    }

    fn validate_cluster(&self) -> Result<()> {
        if self.cluster.token_env.trim().is_empty() {
            return Err(LiveError::Config(
                "cluster.token_env must not be empty".to_owned(),
            ));
        }
        match self.cluster.transport.as_str() {
            "http" => {}
            "iroh" | "both" if cfg!(feature = "p2p") => {}
            "iroh" | "both" => {
                return Err(LiveError::Config(
                    "cluster.transport = \"iroh\" requires a build with the `p2p` feature"
                        .to_owned(),
                ));
            }
            other => {
                return Err(LiveError::Config(format!(
                    "cluster.transport must be \"http\", \"iroh\" or \"both\", not {other:?}"
                )));
            }
        }
        match self.cluster.discovery.as_str() {
            "none" => {}
            "mdns" | "dns" if cfg!(feature = "p2p") => {}
            "mdns" | "dns" => {
                return Err(LiveError::Config(
                    "cluster.discovery requires a build with the `p2p` feature".to_owned(),
                ));
            }
            other => {
                return Err(LiveError::Config(format!(
                    "cluster.discovery must be \"none\", \"mdns\" or \"dns\", not {other:?}"
                )));
            }
        }
        if !self.cluster.relays.is_empty() && !cfg!(feature = "p2p") {
            return Err(LiveError::Config(
                "cluster.relays requires a build with the `p2p` feature".to_owned(),
            ));
        }
        // An HTTP-speaking node must still advertise an endpoint to join
        // anything; an iroh-only node is dialled by key and needs none.
        if !self.cluster.seeds.is_empty()
            && self.cluster.transport != "iroh"
            && self.cluster.advertise_endpoint.is_none()
        {
            return Err(LiveError::Config(
                "cluster.advertise_endpoint is required when cluster.seeds is not empty".to_owned(),
            ));
        }
        if let Some(endpoint) = &self.cluster.advertise_endpoint {
            validate_cluster_endpoint(endpoint)?;
        }
        for endpoint in &self.cluster.seeds {
            validate_cluster_endpoint(endpoint)?;
        }
        if let Ok(token) = env::var(&self.cluster.token_env) {
            if token.len() < 32 {
                return Err(LiveError::Config(format!(
                    "{} must contain at least 32 bytes",
                    self.cluster.token_env
                )));
            }
            if self.auth_token().as_deref() == Some(token.as_str()) {
                return Err(LiveError::Config(
                    "the cluster token must be different from the user authentication token"
                        .to_owned(),
                ));
            }
        }
        if self.cluster.heartbeat_interval_secs == 0
            || self.cluster.request_timeout_secs == 0
            || self.cluster.node_ttl_secs == 0
            || self.cluster.max_peers == 0
            || self.cluster.fanout == 0
            || self.cluster.replication_max_objects_per_round == 0
            || self.cluster.replication_max_object_bytes == 0
            || self.cluster.replication_interval_secs == 0
            || self.cluster.node_ttl_secs <= self.cluster.heartbeat_interval_secs
        {
            return Err(LiveError::Config(
                "cluster intervals, timeout, TTL, peer, and replication bounds must be valid"
                    .to_owned(),
            ));
        }
        if !matches!(self.cluster.admission.as_str(), "token" | "allowlist") {
            return Err(LiveError::Config(format!(
                "unsupported cluster.admission {:?}; expected token or allowlist",
                self.cluster.admission
            )));
        }
        for key in &self.cluster.trusted_keys {
            crate::cluster::identity::parse_node_id(key).map_err(|error| {
                LiveError::Config(format!("cluster.trusted_keys entry {key:?}: {error}"))
            })?;
        }
        if self.cluster.admission == "allowlist" && self.cluster.trusted_keys.is_empty() {
            return Err(LiveError::Config(
                "cluster.admission \"allowlist\" requires at least one cluster.trusted_keys entry"
                    .to_owned(),
            ));
        }
        Ok(())
    }

    fn validate_registry(&self) -> Result<()> {
        match self.registry.provider.as_str() {
            "local" => {}
            "kappa" => {
                // Fail at startup rather than on the first request, so a
                // misconfigured daemon never reports itself ready.
                if self.registry.endpoint.trim().is_empty() {
                    return Err(LiveError::Config(
                        "registry.endpoint is required when registry.provider is \"kappa\""
                            .to_owned(),
                    ));
                }
                if self.registry.namespace.trim().is_empty() {
                    return Err(LiveError::Config(
                        "registry.namespace is required when registry.provider is \"kappa\""
                            .to_owned(),
                    ));
                }
            }
            other => {
                return Err(LiveError::Config(format!(
                    "unsupported registry.provider {other:?}; expected local or kappa"
                )))
            }
        }
        Ok(())
    }

    fn validate_holo_resident(&self) -> Result<()> {
        let mut seen = std::collections::BTreeSet::new();
        for entry in &self.holo.resident {
            let kappa = entry.kappa.trim();
            let digest = kappa.strip_prefix("blake3:").ok_or_else(|| {
                LiveError::Config(format!(
                    "holo.resident kappa {kappa:?} must start with \"blake3:\""
                ))
            })?;
            if digest.len() != 64 || !digest.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(LiveError::Config(format!(
                    "holo.resident kappa {kappa:?} must be \"blake3:\" followed by 64 hex characters"
                )));
            }
            if !seen.insert(kappa.to_owned()) {
                return Err(LiveError::Config(format!(
                    "duplicate holo.resident kappa {kappa}"
                )));
            }
        }
        Ok(())
    }

    fn validate_plugins(&self) -> Result<()> {
        let builtin_ids = crate::modules::builtin_ids();
        let mut seen = std::collections::BTreeSet::new();
        for module in &self.plugins.modules {
            if module.id.trim().is_empty() {
                return Err(LiveError::Config(
                    "plugins.modules entries must declare a non-empty id".to_owned(),
                ));
            }
            if builtin_ids.iter().any(|id| id == &module.id) {
                return Err(LiveError::Config(format!(
                    "plugin id {} collides with a builtin module id",
                    module.id
                )));
            }
            if !seen.insert(module.id.clone()) {
                return Err(LiveError::Config(format!(
                    "duplicate plugin id {}",
                    module.id
                )));
            }
            if module.path.as_os_str().is_empty() {
                return Err(LiveError::Config(format!(
                    "plugin {} must declare a non-empty path",
                    module.id
                )));
            }
            let sha256 = &module.sha256;
            if sha256.len() != 64 || !sha256.bytes().all(|byte| byte.is_ascii_hexdigit()) {
                return Err(LiveError::Config(format!(
                    "plugin {} sha256 must be 64 hex characters",
                    module.id
                )));
            }
        }
        Ok(())
    }

    /// Where registry mode serves administration: the module API and gRPC,
    /// including `shutdown`. A Unix socket, mode 0600, under the state
    /// directory, so `docker exec` reaches it and the network cannot (FR-S06).
    pub fn admin_socket(&self) -> PathBuf {
        self.paths.state_dir.join("admin.sock")
    }

    fn validate_registry_mode(&self) -> Result<()> {
        let allowed = [
            "dev.hologram.live.system",
            "dev.hologram.live.control-plane",
            "dev.hologram.live.oci",
        ];
        if let Some(extra) = self
            .modules
            .enabled
            .iter()
            .find(|id| !allowed.contains(&id.as_str()))
        {
            return Err(LiveError::Config(format!(
                "registry mode runs only the system and registry modules, not {extra}"
            )));
        }
        if self.plugins.enabled {
            return Err(LiveError::Config(
                "registry mode runs no plugins: set plugins.enabled = false".to_owned(),
            ));
        }
        // sun_path is 108 bytes on Linux and 104 on macOS, with the final NUL.
        #[cfg(unix)]
        {
            let socket = self.admin_socket();
            if socket.as_os_str().len() >= 104 {
                return Err(LiveError::Config(format!(
                    "the administration socket path is too long for a Unix socket ({} bytes): {}; use a shorter storage.filesystem.rootdirectory",
                    socket.as_os_str().len(),
                    socket.display()
                )));
            }
        }
        Ok(())
    }

    pub fn auth_token(&self) -> Option<String> {
        env::var(&self.auth.token_env).ok()
    }

    pub fn cluster_token(&self) -> Option<String> {
        env::var(&self.cluster.token_env).ok()
    }

    fn apply_environment(&mut self) -> Result<()> {
        if let Ok(value) = env::var("HOLOGRAM_LISTEN") {
            self.server.listen = value;
        }
        if let Ok(value) = env::var("HOLOGRAM_MAX_RPC_BYTES") {
            self.server.max_rpc_bytes = value.parse().map_err(|error| {
                LiveError::Config(format!(
                    "HOLOGRAM_MAX_RPC_BYTES must be a positive byte count: {error}"
                ))
            })?;
        }
        if let Ok(value) = env::var("HOLOGRAM_REMOTE_ENDPOINT") {
            self.client.remote_endpoint = Some(value);
        }
        if let Ok(value) = env::var("HOLOGRAM_LOG") {
            self.tracing.filter = value;
        } else if let Ok(value) = env::var("RUST_LOG") {
            self.tracing.filter = value;
        }
        if let Ok(value) = env::var("OTEL_EXPORTER_OTLP_ENDPOINT") {
            self.telemetry.endpoint = Some(value);
        }
        if let Ok(value) = env::var("OTEL_SERVICE_NAME") {
            self.telemetry.service_name = value;
        }
        if let Some(value) = env::var_os("HOLOGRAM_DATA_DIR") {
            self.paths.data_dir = PathBuf::from(value);
        }
        if let Some(value) = env::var_os("HOLOGRAM_STATE_DIR") {
            self.paths.state_dir = PathBuf::from(value);
        }
        if let Some(value) = env::var_os("HOLOGRAM_CACHE_DIR") {
            self.paths.cache_dir = PathBuf::from(value);
        }
        Ok(())
    }

    fn expand_paths(&mut self) {
        self.paths.config_dir = expand_home(&self.paths.config_dir);
        self.paths.data_dir = expand_home(&self.paths.data_dir);
        self.paths.state_dir = expand_home(&self.paths.state_dir);
        self.paths.cache_dir = expand_home(&self.paths.cache_dir);
        for module in &mut self.plugins.modules {
            module.path = expand_home(&module.path);
        }
        if let Some(path) = &mut self.holo.development_grant {
            *path = expand_home(&*path);
            if path.is_relative() {
                *path = self.paths.config_dir.join(&*path);
            }
        }
    }
}

fn is_loopback(ip: IpAddr) -> bool {
    ip.is_loopback()
}

fn validate_endpoint(endpoint: &str, local: bool) -> Result<()> {
    if endpoint.starts_with("https://") {
        return Ok(());
    }
    if endpoint.starts_with("http://127.0.0.1")
        || endpoint.starts_with("http://localhost")
        || endpoint.starts_with("http://[::1]")
    {
        return Ok(());
    }
    let kind = if local { "local" } else { "remote" };
    Err(LiveError::Config(format!(
        "{kind} endpoint must use HTTPS unless it is loopback: {endpoint}"
    )))
}

pub(crate) fn validate_cluster_endpoint(endpoint: &str) -> Result<()> {
    if let Some(rest) = endpoint.strip_prefix("iroh:") {
        // Key-addressed: the address is the identity, so it is exactly the
        // node id — `ed25519:<64 lowercase hex>`, nothing else.
        if !cfg!(feature = "p2p") {
            return Err(LiveError::Config(format!(
                "cluster endpoint {endpoint} is key-addressed (iroh) and requires a build with the `p2p` feature"
            )));
        }
        return crate::cluster::identity::parse_node_id(rest)
            .map(|_| ())
            .map_err(|error| {
                LiveError::Config(format!("invalid iroh cluster endpoint {endpoint}: {error}"))
            });
    }
    let parsed = reqwest::Url::parse(endpoint)
        .map_err(|error| LiveError::Config(format!("invalid cluster endpoint: {error}")))?;
    let host = parsed
        .host_str()
        .ok_or_else(|| LiveError::Config(format!("cluster endpoint has no host: {endpoint}")))?;
    let loopback = host == "localhost"
        || host
            .parse::<IpAddr>()
            .is_ok_and(|address| address.is_loopback());
    if parsed.scheme() != "https" && !(parsed.scheme() == "http" && loopback) {
        return Err(LiveError::Config(format!(
            "cluster endpoint must use HTTPS unless it is loopback: {endpoint}"
        )));
    }
    if parsed.path() != "/"
        || parsed.query().is_some()
        || parsed.fragment().is_some()
        || !parsed.username().is_empty()
        || parsed.password().is_some()
    {
        return Err(LiveError::Config(format!(
            "cluster endpoint must be a credential-free origin: {endpoint}"
        )));
    }
    Ok(())
}

fn validate_compiled_local_engine(
    compiled: bool,
    engine: &str,
    inference: &InferenceConfig,
    accepts_imported_model: bool,
) -> Result<()> {
    if !compiled {
        return Err(LiveError::Config(format!(
            "inference.engine {engine:?} needs a build with --features {engine}"
        )));
    }
    if inference.model_path.trim().is_empty()
        && (!accepts_imported_model || inference.default_model.trim().is_empty())
    {
        let source = if accepts_imported_model {
            "inference.model_path or an imported inference.default_model"
        } else {
            "inference.model_path"
        };
        return Err(LiveError::Config(format!("{engine} requires {source}")));
    }
    if inference.tokenizer_path.trim().is_empty() {
        return Err(LiveError::Config(format!(
            "{engine} requires inference.tokenizer_path"
        )));
    }
    Ok(())
}

#[cfg(test)]
mod tests {

    #[test]
    fn registry_defaults_to_the_local_provider() {
        let config = AppConfig::default();
        assert_eq!(
            config.registry.provider, "local",
            "hologram must stay a single binary needing no external service"
        );
    }

    #[test]
    fn a_config_written_before_the_registry_section_still_loads() {
        // Adding a defaulted section must not require a schema bump, because
        // the version machinery exists for retired keys, not for additions.
        let document = r#"
schema_version = 2
[server]
listen = "127.0.0.1:4455"
"#;
        let config: AppConfig = toml::from_str(document).expect("older config must load");
        assert_eq!(config.registry.provider, "local");
        assert_eq!(config.registry.max_scan_pages, 20);
    }

    #[test]
    fn selecting_the_kappa_provider_without_an_endpoint_is_a_config_error() {
        let mut config = AppConfig::default();
        config.registry.provider = "kappa".to_owned();
        config.registry.endpoint = String::new();

        let error = config
            .validate()
            .expect_err("an unreachable provider must fail early");
        match error {
            LiveError::Config(message) => assert!(
                message.contains("registry.endpoint"),
                "the missing endpoint must be named, got {message:?}"
            ),
            other => panic!("expected a config error, got {other:?}"),
        }
    }

    #[test]
    fn a_fully_configured_kappa_provider_validates() {
        // The adapter now exists, so a complete configuration must be accepted.
        // Plan 1 refused this outright to avoid silently serving from the local
        // store; that refusal is replaced by a real provider, not relaxed into
        // a fallback.
        let mut config = AppConfig::default();
        config.registry.provider = "kappa".to_owned();

        config
            .validate()
            .expect("a kappa provider with an endpoint and namespace is valid");
    }

    #[test]
    fn selecting_the_kappa_provider_without_a_namespace_is_a_config_error() {
        let mut config = AppConfig::default();
        config.registry.provider = "kappa".to_owned();
        config.registry.namespace = String::new();

        let error = config
            .validate()
            .expect_err("a namespace-less remote provider must fail early");
        match error {
            LiveError::Config(message) => assert!(
                message.contains("registry.namespace"),
                "the missing namespace must be named, got {message:?}"
            ),
            other => panic!("expected a config error, got {other:?}"),
        }
    }

    #[test]
    fn an_unknown_registry_provider_is_rejected() {
        let mut config = AppConfig::default();
        config.registry.provider = "postgres".to_owned();

        let error = config.validate().expect_err("unknown providers must fail");
        assert!(matches!(error, LiveError::Config(_)));
    }
    use super::*;

    #[test]
    fn default_config_uses_uniform_config_directory() {
        assert!(AppConfig::default_path().ends_with(".config/hologram/live.toml"));
    }

    #[test]
    fn insecure_remote_endpoint_is_rejected() {
        let mut config = AppConfig::default();
        config.client.remote_endpoint = Some("http://example.com".to_owned());
        assert!(config.validate().is_err());
    }

    /// Registry mode may face a network with no token, as the reference does,
    /// because its public listener carries only /v2/ (ADR 028). No other
    /// module, and no plugin, rides along.
    #[test]
    fn registry_mode_allows_a_public_anonymous_listener_and_nothing_else() {
        let mut config = AppConfig {
            registry_mode: true,
            ..AppConfig::default()
        };
        config.server.listen = "0.0.0.0:5000".to_owned();
        config.modules.enabled = vec![
            "dev.hologram.live.system".to_owned(),
            "dev.hologram.live.oci".to_owned(),
        ];
        if let Err(error) = config.validate() {
            panic!("the reference's own default is a public anonymous registry: {error}");
        }
        config
            .modules
            .enabled
            .push("dev.hologram.live.files".to_owned());
        let error = config.validate().expect_err("only system and registry");
        assert!(
            error.to_string().contains("dev.hologram.live.files"),
            "{error}"
        );
        config.modules.enabled.pop();
        config.plugins.enabled = true;
        assert!(config.validate().is_err(), "no plugins in registry mode");
        config.plugins.enabled = false;
        // Out of registry mode the loopback rule is exactly as before.
        config.registry_mode = false;
        assert!(config.validate().is_err());
    }

    #[cfg(unix)]
    #[test]
    fn registry_mode_names_a_socket_path_that_is_too_long() {
        let mut config = AppConfig {
            registry_mode: true,
            ..AppConfig::default()
        };
        config.modules.enabled = vec!["dev.hologram.live.system".to_owned()];
        config.paths.state_dir = PathBuf::from(format!("/{}", "d".repeat(100)));
        // 104 bytes, macOS's sun_path, is the limit on every Unix.
        let error = config
            .validate()
            .expect_err("the path does not fit sun_path");
        assert!(error.to_string().contains("admin.sock"), "{error}");
    }

    #[cfg(feature = "oci")]
    #[test]
    fn the_registry_module_is_refused_on_a_public_listener_even_with_auth_required() {
        let mut config = AppConfig::default();
        config.server.listen = "0.0.0.0:5000".to_owned();
        config.auth.required = true;
        // Any variable that is always set stands in for the token; setting one
        // from a test would race the other tests.
        "PATH".clone_into(&mut config.auth.token_env);
        if let Err(error) = config.validate() {
            panic!("the rest of the server may face a network: {error}");
        }
        config
            .modules
            .enabled
            .push(crate::modules::oci::MODULE_ID.to_owned());
        let error = config
            .validate()
            .expect_err("the registry has no login yet");
        assert!(error.to_string().contains("loopback"), "{error}");
        config.server.listen = "127.0.0.1:5000".to_owned();
        assert!(config.validate().is_ok());
    }

    #[test]
    fn default_config_enables_the_builtin_module_catalogue() {
        assert_eq!(
            ModulesConfig::default().enabled,
            crate::modules::default_builtin_ids()
        );
    }

    #[test]
    fn noncurrent_configuration_schema_is_rejected() {
        let config = AppConfig {
            schema_version: 1,
            ..AppConfig::default()
        };
        let error = config.validate().expect_err("old schema");
        assert!(error
            .to_string()
            .contains("unsupported configuration schema 1"));
    }

    /// Each test gets its own directory so nothing races on a shared path.
    fn scratch_config(name: &str, body: &str) -> (PathBuf, PathBuf) {
        let dir = env::temp_dir().join(format!("hologram-config-{}-{name}", std::process::id()));
        std::fs::create_dir_all(&dir).expect("create scratch dir");
        let path = dir.join("live.toml");
        std::fs::write(&path, body).expect("write scratch config");
        (dir, path)
    }

    const LEGACY: &[RetiredKey] = &[
        RetiredKey {
            path: "server.legacy_timeout_secs",
            removed_in: 2,
        },
        RetiredKey {
            path: "legacy",
            removed_in: 2,
        },
    ];

    /// The point of the mechanism: a file written before a field was removed
    /// still starts, instead of being refused by `deny_unknown_fields`.
    #[test]
    fn keys_retired_by_a_newer_schema_are_dropped_when_upgrading() {
        let source = r#"
schema_version = 1

[server]
listen = "127.0.0.1:11435"
legacy_timeout_secs = 5

[legacy]
whatever = true
"#;
        let config = AppConfig::from_source(source, true, Path::new("live.toml"), LEGACY)
            .expect("a file predating the removal must still load");
        // Everything the current schema still knows about survives the prune.
        assert_eq!(config.server.listen, "127.0.0.1:11435");
        assert_eq!(
            config.schema_version, 1,
            "migrate stamps the version, not this"
        );
    }

    /// Typo protection is the reason `deny_unknown_fields` was kept, so a file
    /// already at the current version must not have stray keys swept away.
    #[test]
    fn retired_keys_are_not_dropped_from_a_current_file() {
        let source = format!(
            "schema_version = {CURRENT_SCHEMA_VERSION}\n\n[server]\nlegacy_timeout_secs = 5\n"
        );
        let error = AppConfig::from_source(&source, true, Path::new("live.toml"), LEGACY)
            .expect_err("a current file keeps strict field checking");
        assert!(error.to_string().contains("legacy_timeout_secs"), "{error}");
    }

    #[test]
    fn bootstrap_parsing_never_prunes() {
        let source = "schema_version = 1\n\n[server]\nlegacy_timeout_secs = 5\n";
        let error = AppConfig::from_source(source, false, Path::new("live.toml"), LEGACY)
            .expect_err("the bootstrap read stays strict");
        assert!(error.to_string().contains("legacy_timeout_secs"), "{error}");
    }

    #[test]
    fn pruning_reports_only_the_paths_it_actually_removed() {
        let mut table =
            toml::from_str::<toml::Table>("schema_version = 1\n\n[server]\nlisten = \"x\"\n")
                .expect("parse table");

        let dropped = prune_retired_keys(&mut table, 1, LEGACY);

        assert!(
            dropped.is_empty(),
            "nothing retired was present: {dropped:?}"
        );
        assert!(table.contains_key("server"), "untouched keys stay");
    }

    #[test]
    fn pruning_skips_keys_retired_at_or_before_the_files_version() {
        let mut table = toml::from_str::<toml::Table>("[server]\nlegacy_timeout_secs = 5\n")
            .expect("parse table");

        // The file is already at 2, so a key retired in 2 is not swept.
        let dropped = prune_retired_keys(&mut table, 2, LEGACY);

        assert!(dropped.is_empty(), "{dropped:?}");
    }

    #[test]
    fn dotted_removal_handles_nested_and_top_level_paths() {
        let mut table = toml::from_str::<toml::Table>("[a]\nb = 1\nkeep = 2\n\n[top]\nx = 1\n")
            .expect("parse table");

        assert!(remove_dotted(&mut table, "a.b"));
        assert!(remove_dotted(&mut table, "top"));
        assert!(
            !remove_dotted(&mut table, "a.missing"),
            "absent key reports false"
        );
        assert!(
            !remove_dotted(&mut table, "missing.deep"),
            "absent parent reports false"
        );

        assert!(!table.contains_key("top"));
        let a = table
            .get("a")
            .and_then(toml::Value::as_table)
            .expect("table a");
        assert!(!a.contains_key("b"));
        assert!(a.contains_key("keep"), "siblings survive");
    }

    #[test]
    fn older_configuration_is_upgraded_and_rewritten() {
        let (dir, path) = scratch_config("upgrade", "schema_version = 1\nrole = \"node\"\n");

        let (config, loaded) = AppConfig::load(Some(&path)).expect("older config must load");
        assert_eq!(config.schema_version, CURRENT_SCHEMA_VERSION);
        assert_eq!(loaded, path);

        let rewritten = std::fs::read_to_string(&path).expect("read rewritten config");
        assert!(
            rewritten.contains(&format!("schema_version = {CURRENT_SCHEMA_VERSION}")),
            "{rewritten}"
        );
        // The upgrade is written out in full, so the next start reads a file
        // that no longer depends on defaulting to fill the gaps.
        assert!(rewritten.contains("[inference]"), "{rewritten}");
        assert!(rewritten.contains("[plugins]"), "{rewritten}");

        std::fs::remove_dir_all(&dir).ok();
    }

    /// The upgrade must round-trip what the user wrote, not what the process
    /// resolved it to. `~` expansion happens after the rewrite, so an expanded
    /// absolute path must never reach the file.
    #[test]
    fn upgrade_persists_only_what_the_user_wrote() {
        let (dir, path) = scratch_config(
            "no-leak",
            "schema_version = 1\n\n[paths]\ndata_dir = \"~/hologram-data\"\n",
        );

        let (config, _) = AppConfig::load(Some(&path)).expect("older config must load");
        assert!(
            !config.paths.data_dir.starts_with("~"),
            "in-memory path stays unexpanded: {}",
            config.paths.data_dir.display()
        );

        let rewritten = std::fs::read_to_string(&path).expect("read rewritten config");
        assert!(
            rewritten.contains("~/hologram-data"),
            "expansion leaked into the file: {rewritten}"
        );

        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn newer_configuration_schema_is_refused() {
        let (dir, path) = scratch_config("newer", "schema_version = 99\n");

        let error = AppConfig::load(Some(&path)).expect_err("newer schema must fail");
        assert!(
            error.to_string().contains("newer than this build supports"),
            "{error}"
        );
        let untouched = std::fs::read_to_string(&path).expect("read config");
        assert!(untouched.contains("99"), "{untouched}");

        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn configuration_schema_below_the_supported_floor_is_refused() {
        let (dir, path) = scratch_config("floor", "schema_version = 0\n");

        let error = AppConfig::load(Some(&path)).expect_err("schema 0 must fail");
        assert!(error.to_string().contains("predates"), "{error}");

        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn current_configuration_is_left_untouched() {
        let body =
            format!("schema_version = {CURRENT_SCHEMA_VERSION}\n# a comment worth keeping\n");
        let (dir, path) = scratch_config("current", &body);

        AppConfig::load(Some(&path)).expect("current config loads");

        let after = std::fs::read_to_string(&path).expect("read config");
        assert_eq!(after, body, "a current config must not be rewritten");

        std::fs::remove_dir_all(&dir).ok();
    }

    /// The bootstrap read happens before a tracing subscriber exists, so it
    /// must not perform an upgrade whose log line would be dropped.
    #[test]
    fn bootstrap_load_never_rewrites_the_file() {
        let body = "schema_version = 1\n";
        let (dir, path) = scratch_config("bootstrap", body);

        AppConfig::load_for_bootstrap(Some(&path)).expect_err("stale config fails validate");

        let after = std::fs::read_to_string(&path).expect("read config");
        assert_eq!(after, body, "bootstrap must leave the file alone");

        std::fs::remove_dir_all(&dir).ok();
    }

    #[test]
    fn missing_section_fields_fall_back_to_defaults() {
        let mut value = toml::Value::try_from(AppConfig::default()).expect("serialize config");
        value
            .get_mut("server")
            .and_then(toml::Value::as_table_mut)
            .expect("server table")
            .remove("max_rpc_bytes");
        let source = toml::to_string(&value).expect("encode config");
        let config = toml::from_str::<AppConfig>(&source).expect("field added after this file");
        assert_eq!(
            config.server.max_rpc_bytes,
            ServerConfig::default().max_rpc_bytes
        );
        config.validate().expect("defaulted config validates");
    }

    /// A config written before `[inference]`, `[holo]`, and `[plugins]` existed
    /// must still boot: `schema_version` is unchanged, so the file is current
    /// as far as its author knew.
    #[test]
    fn configuration_predating_a_whole_section_still_loads() {
        let source = r#"
schema_version = 2
role = "node"

[server]
listen = "127.0.0.1:11435"

[modules]
enabled = ["dev.hologram.live.system"]
"#;
        let config = toml::from_str::<AppConfig>(source).expect("older config must load");
        assert_eq!(config.inference.engine, InferenceConfig::default().engine);
        assert!(config.holo.resident.is_empty());
        assert!(!config.plugins.enabled);
        assert_eq!(config.server.listen, "127.0.0.1:11435");
        assert_eq!(config.modules.enabled, ["dev.hologram.live.system"]);
        config.validate().expect("older config validates");
    }

    #[test]
    fn missing_schema_version_is_rejected() {
        let error = toml::from_str::<AppConfig>("role = \"node\"\n")
            .expect_err("schema_version anchors compatibility and is never guessed");
        assert!(error.to_string().contains("schema_version"), "{error}");
    }

    #[test]
    fn unknown_configuration_fields_are_still_rejected() {
        let mut value = toml::Value::try_from(AppConfig::default()).expect("serialize config");
        value
            .get_mut("server")
            .and_then(toml::Value::as_table_mut)
            .expect("server table")
            .insert("listne".to_owned(), toml::Value::String("oops".to_owned()));
        let source = toml::to_string(&value).expect("encode config");
        let error = toml::from_str::<AppConfig>(&source).expect_err("typo must fail");
        assert!(error.to_string().contains("listne"), "{error}");
    }

    #[test]
    fn plugin_entries_still_require_every_field() {
        let source = r#"
schema_version = 2

[plugins]
enabled = true

[[plugins.modules]]
id = "dev.example.plugin"
path = "/usr/local/bin/plugin"
"#;
        let error = toml::from_str::<AppConfig>(source)
            .expect_err("hand-authored list entries stay strict");
        assert!(error.to_string().contains("sha256"), "{error}");
    }

    #[test]
    fn inference_defaults_to_the_local_echo_engine() {
        let config = AppConfig::default();
        assert_eq!(config.inference.engine, "echo");
        assert!(config.inference.default_model.is_empty());
        assert_eq!(config.inference.weightc_path, "weightc");
        assert_eq!(config.inference.ollama_endpoint, "http://127.0.0.1:11434");
        assert_eq!(config.inference.vllm_endpoint, "http://127.0.0.1:8000");
        assert_eq!(config.inference.vllm_token_env, "VLLM_API_KEY");
        assert!(config.inference.model_path.is_empty());
        assert!(config.inference.tokenizer_path.is_empty());
        assert!(config.inference.model_architecture.is_empty());
        assert_eq!(config.inference.n_ctx, 4096);
        assert_eq!(config.inference.n_gpu_layers, 0);
        assert_eq!(config.inference.llamacpp_max_concurrent_requests, 1);
        assert_eq!(config.inference.request_timeout_secs, 300);
        assert!(!config.inference.resident_sessions);
        assert_eq!(config.inference.max_resident_sessions, 4);
        config.validate().expect("default config validates");
    }

    #[test]
    fn zero_max_resident_sessions_is_rejected() {
        let mut config = AppConfig::default();
        config.inference.max_resident_sessions = 0;
        let error = config.validate().expect_err("must fail");
        assert!(
            error.to_string().contains("max_resident_sessions"),
            "{error}"
        );
    }

    #[test]
    fn unknown_inference_engine_is_rejected() {
        let mut config = AppConfig::default();
        config.inference.engine = "surprise".to_owned();
        assert!(config.validate().is_err());
    }

    #[test]
    fn llamacpp_requires_the_feature_and_a_model_source() {
        let mut config = AppConfig::default();
        config.inference.engine = "llamacpp".to_owned();
        config.inference.model_path = "/models/tiny.gguf".to_owned();
        let result = config.validate();
        if cfg!(feature = "llamacpp") {
            assert!(result.is_ok(), "{result:?}");
        } else {
            let error = result.expect_err("featureless build must reject llamacpp");
            assert!(error.to_string().contains("--features llamacpp"), "{error}");
        }

        config.inference.model_path.clear();
        config.inference.default_model = "blake3:imported".to_owned();
        let imported = config.validate();
        if cfg!(feature = "llamacpp") {
            assert!(imported.is_ok(), "{imported:?}");
        } else {
            assert!(imported.is_err());
        }
    }

    #[test]
    fn vllm_is_a_supported_inference_engine() {
        let mut config = AppConfig::default();
        config.inference.engine = "vllm".to_owned();
        config.inference.default_model = "org/model".to_owned();
        config.validate().expect("vllm config");
    }

    #[test]
    fn candle_requires_its_feature_and_explicit_model_contract() {
        let mut config = AppConfig::default();
        config.inference.engine = "candle".to_owned();
        config.inference.model_path = "/models/model.gguf".to_owned();
        config.inference.tokenizer_path = "/models/tokenizer.json".to_owned();
        config.inference.model_architecture = "llama".to_owned();
        let result = config.validate();
        if cfg!(feature = "candle") {
            result.expect("compiled Candle configuration");
        } else {
            let error = result.expect_err("featureless build must reject Candle");
            assert!(error.to_string().contains("--features candle"), "{error}");
        }
    }

    #[test]
    fn burn_requires_its_feature_and_explicit_model_contract() {
        let mut config = AppConfig::default();
        config.inference.engine = "burn".to_owned();
        config.inference.model_path = "/models/model.mpk".to_owned();
        config.inference.tokenizer_path = "/models/tokenizer.model".to_owned();
        config.inference.model_architecture = "llama3.2-1b".to_owned();
        let result = config.validate();
        if cfg!(feature = "burn") {
            result.expect("compiled Burn configuration");
        } else {
            let error = result.expect_err("featureless build must reject Burn");
            assert!(error.to_string().contains("--features burn"), "{error}");
        }
    }

    #[test]
    fn current_config_can_intentionally_disable_chat() {
        let mut config = AppConfig::default();
        config
            .modules
            .enabled
            .retain(|id| id != "dev.hologram.live.chat");

        config.validate().expect("current config");
        assert!(!config
            .modules
            .enabled
            .iter()
            .any(|id| id == "dev.hologram.live.chat"));
    }

    #[test]
    fn plugins_default_to_disabled_with_an_empty_allowlist() {
        let config = AppConfig::default();
        assert!(!config.plugins.enabled);
        assert!(config.plugins.modules.is_empty());
        config.validate().expect("default config validates");
    }

    #[test]
    fn holo_development_grants_are_explicit_and_resolve_from_config_dir() {
        let mut config = AppConfig::default();
        assert!(config.holo.development_grant.is_none());
        config.paths.config_dir = PathBuf::from("/tmp/hologram-config");
        config.holo.development_grant = Some(PathBuf::from("development-grant.json"));

        config.expand_paths();

        assert_eq!(
            config.holo.development_grant,
            Some(PathBuf::from("/tmp/hologram-config/development-grant.json"))
        );
    }

    #[test]
    fn holo_development_grant_is_rejected_on_non_loopback_servers() {
        let mut config = AppConfig::default();
        config.server.listen = "0.0.0.0:11435".to_owned();
        config.auth.required = true;
        config.holo.development_grant = Some(PathBuf::from("grant.json"));

        let error = config
            .validate()
            .expect_err("development grant must stay local");
        assert!(error.to_string().contains("loopback"), "{error}");
    }

    #[test]
    fn holo_resident_declarations_parse_and_validate() {
        let source = format!(
            "{}\n[[holo.resident]]\nkappa = \"blake3:{}\"\n",
            toml::to_string(&AppConfig::default()).expect("encode default config"),
            "ab".repeat(32)
        );
        let config = toml::from_str::<AppConfig>(&source).expect("parse resident declaration");
        assert_eq!(config.holo.resident.len(), 1);
        assert_eq!(
            config.holo.resident[0].kappa,
            format!("blake3:{}", "ab".repeat(32))
        );
        config.validate().expect("resident declaration validates");
    }

    #[test]
    fn holo_resident_declarations_default_to_empty() {
        let config = AppConfig::default();
        assert!(config.holo.resident.is_empty());
        config.validate().expect("default config validates");
    }

    #[test]
    fn holo_resident_kappas_must_be_well_formed() {
        let mut config = AppConfig::default();
        config.holo.resident.push(HoloResidentConfig {
            kappa: "sha256:abc".to_owned(),
        });
        let error = config.validate().expect_err("prefix must fail");
        assert!(error.to_string().contains("blake3:"), "{error}");

        let mut config = AppConfig::default();
        config.holo.resident.push(HoloResidentConfig {
            kappa: "blake3:abc".to_owned(),
        });
        let error = config.validate().expect_err("length must fail");
        assert!(error.to_string().contains("64 hex"), "{error}");
    }

    #[test]
    fn holo_resident_kappas_must_be_unique() {
        let mut config = AppConfig::default();
        let kappa = format!("blake3:{}", "cd".repeat(32));
        config.holo.resident.push(HoloResidentConfig {
            kappa: kappa.clone(),
        });
        config.holo.resident.push(HoloResidentConfig { kappa });
        let error = config.validate().expect_err("duplicate must fail");
        assert!(error.to_string().contains("duplicate"), "{error}");
    }

    #[test]
    fn plugin_entries_require_a_well_formed_sha256() {
        let mut config = plugin_config();
        config.plugins.modules[0].sha256 = "not-hex".to_owned();
        let error = config.validate().expect_err("must fail");
        assert!(error.to_string().contains("64 hex"), "{error}");

        let mut config = plugin_config();
        config.plugins.modules[0].sha256 = "ab".repeat(32).to_uppercase();
        config.validate().expect("uppercase hex is accepted");
    }

    #[test]
    fn plugin_ids_must_be_unique_and_not_shadow_builtins() {
        let mut config = plugin_config();
        let duplicate = config.plugins.modules[0].clone();
        config.plugins.modules.push(duplicate);
        let error = config.validate().expect_err("duplicate id must fail");
        assert!(error.to_string().contains("duplicate plugin id"), "{error}");

        let mut config = plugin_config();
        config.plugins.modules[0].id = "dev.hologram.live.system".to_owned();
        let error = config.validate().expect_err("builtin id must fail");
        assert!(error.to_string().contains("builtin module id"), "{error}");
    }

    #[test]
    fn plugin_entries_require_an_id_and_a_path() {
        let mut config = plugin_config();
        config.plugins.modules[0].id = " ".to_owned();
        assert!(config.validate().is_err());

        let mut config = plugin_config();
        config.plugins.modules[0].path = PathBuf::new();
        assert!(config.validate().is_err());
    }

    fn plugin_config() -> AppConfig {
        let mut config = AppConfig::default();
        config.plugins.enabled = true;
        config.plugins.modules.push(PluginModuleConfig {
            id: "com.example.echo".to_owned(),
            path: PathBuf::from("/opt/plugins/echo"),
            sha256: "ab".repeat(32),
        });
        config
    }

    // Review Focus 2: a bad key must fail at startup, not at the first join.
    #[test]
    fn a_malformed_trusted_key_is_rejected_at_startup() {
        let mut config = AppConfig::default();
        config.cluster.trusted_keys = vec!["not-a-key".to_owned()];
        let error = config.validate().expect_err("malformed trusted key");
        assert!(matches!(error, LiveError::Config(_)), "got {error:?}");
    }

    #[test]
    fn an_unsupported_admission_mode_is_rejected() {
        let mut config = AppConfig::default();
        config.cluster.admission = "anyone".to_owned();
        assert!(config.validate().is_err());
    }

    // Phase 2a (#179): a key-addressed seed is a configuration error with a
    // name in it, never a silently ignored value — a node that quietly skipped
    // the `iroh:` seed would not join the cluster its configuration says it
    // should.
    #[cfg(not(feature = "p2p"))]
    #[test]
    fn an_iroh_seed_without_the_p2p_feature_is_a_clear_error() {
        let mut config = AppConfig::default();
        config.cluster.seeds = vec![format!("iroh:ed25519:{}", "a".repeat(64))];
        let error = config.validate().expect_err("an iroh seed must fail");
        match error {
            LiveError::Config(message) => assert!(
                message.contains("p2p"),
                "the error must name the missing feature, got {message:?}"
            ),
            other => panic!("expected a config error, got {other:?}"),
        }
    }

    #[cfg(feature = "p2p")]
    #[test]
    fn an_iroh_only_node_needs_no_advertised_endpoint() {
        let mut config = AppConfig::default();
        config.cluster.transport = "iroh".to_owned();
        config.cluster.advertise_endpoint = None;
        config.cluster.seeds = vec![format!("iroh:ed25519:{}", "a".repeat(64))];
        config
            .validate()
            .expect("a key-addressed node is dialled by key and advertises nothing");
    }

    #[cfg(not(feature = "p2p"))]
    #[test]
    fn the_iroh_transport_without_the_feature_is_a_clear_error() {
        let mut config = AppConfig::default();
        config.cluster.transport = "iroh".to_owned();
        let error = config.validate().expect_err("the iroh transport must fail");
        assert!(
            error.to_string().contains("p2p"),
            "the error must name the missing feature, got {error:?}"
        );
    }

    #[test]
    fn the_stock_cluster_transport_and_discovery_defaults_publish_nothing() {
        let config = AppConfig::default();
        assert_eq!(config.cluster.transport, "http");
        assert_eq!(config.cluster.discovery, "none");
        assert!(config.cluster.relays.is_empty());
    }
}
