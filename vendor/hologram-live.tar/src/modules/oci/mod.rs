//! Hologram Registry: the Docker Registry HTTP API v2 and the OCI Distribution
//! API, under `/v2/`, on the Kappa store (`apps/registry`).
//!
//! The module is opt-in, and it authenticates itself (ADR 026): the registry
//! protocol has its own challenge and its own error shape, so these routes are
//! mounted beside the server's bearer layer, not under it.
//!
//! No Kappa type is named here. Storage is `crate::oci_store`.

pub mod auth;
mod blobs;
mod body;
pub mod debug;
mod delete;
pub mod error;
mod listing;
mod manifests;
mod media;
pub mod metrics;
mod openapi;
pub mod path;
pub mod token;
mod respond;
mod uploads;

use crate::app::AppState;
use crate::module::{LiveModule, ModuleDescriptor};
use crate::oci_store::OciStore;
use axum::body::Body;
use axum::extract::{Request, State};
use axum::http::header::{ALLOW, CONTENT_LENGTH, CONTENT_TYPE, LOCATION};
use axum::http::{HeaderValue, StatusCode};
use axum::middleware::{self, Next};
use axum::response::{IntoResponse, Response};
use axum::routing::any;
use axum::Router;
use error::{ErrorCode, OciError};
use path::{BlobVerb, ManifestVerb, Route, UploadVerb};
use std::sync::Arc;
use tracing::Instrument;

pub const MODULE_ID: &str = "dev.hologram.live.oci";

static DESCRIPTOR: ModuleDescriptor = ModuleDescriptor {
    id: MODULE_ID,
    name: "Hologram Registry",
    version: env!("CARGO_PKG_VERSION"),
    dependencies: &["dev.hologram.live.system"],
    // The registry API is HTTP only: it adds no operation to the RPC surface.
    operations: &[],
};

/// What the registry serves from, and how it is set to behave.
#[derive(Clone)]
pub struct Registry {
    pub store: Arc<OciStore>,
    pub settings: Settings,
    /// The server's audit log. The registry's writes go into it as the
    /// server's own writes do. `None` in tests that do not look at it.
    pub audit: Option<crate::audit::AuditLog>,
    /// `auth.htpasswd`; `None` is an anonymous registry, as the reference
    /// is with no `auth` section.
    pub login: Option<Login>,
}

/// How this registry authenticates: a password file, as the reference's
/// `auth.htpasswd`, or bearer tokens, as its `auth.token`.
#[derive(Clone)]
pub enum Login {
    Password(Arc<auth::Htpasswd>),
    Token(Arc<token::TokenAuth>),
}

impl Login {
    /// Who the client is, if they may do this.
    ///
    /// # Errors
    ///
    /// [`auth::Denied`], which decides the answer.
    pub async fn authenticate(
        &self,
        headers: &axum::http::HeaderMap,
        method: &axum::http::Method,
        scope: &path::Scope,
        query: Option<&str>,
    ) -> Result<String, auth::Denied> {
        match self {
            Self::Password(file) => file.authenticate(headers).await,
            Self::Token(token) => token.authenticate(headers, method, scope, query),
        }
    }

    /// The answer for a client that may not.
    #[must_use]
    pub fn refuse(
        &self,
        denied: &auth::Denied,
        method: &axum::http::Method,
        scope: &path::Scope,
        query: Option<&str>,
    ) -> axum::response::Response {
        match self {
            Self::Password(file) => file.refuse(denied, method, scope, query),
            Self::Token(token) => match denied {
                auth::Denied::Broken(reason) => {
                    tracing::error!(reason = reason.as_str(), "error checking authorization");
                    axum::http::StatusCode::BAD_REQUEST.into_response()
                }
                auth::Denied::Challenge => token.refuse(method, scope, query),
            },
        }
    }
}

/// The issuer this registry runs, when `auth.token.local` is set.
fn local_issuer() -> Option<std::sync::Arc<token::LocalIssuer>> {
    match LOGIN.get()? {
        Some(Login::Token(token)) => token.issuer_side(),
        _ => None,
    }
}

/// `GET /auth/token`: what a client fetches when the challenge sends it here.
/// Anonymous asks get the read half of what they asked for; a password gets
/// everything the password file allows.
async fn issue_token(
    headers: axum::http::HeaderMap,
    uri: axum::http::Uri,
) -> axum::response::Response {
    let Some(issuer) = local_issuer() else {
        return (StatusCode::NOT_FOUND, "this registry does not issue tokens").into_response();
    };
    let query = uri.query();
    let scopes = path::query_params(query, "scope").join(" ");
    match issuer.issue(&headers, &scopes).await {
        Ok(jwt) => {
            let at = token::rfc3339(
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_secs(),
            );
            let body = serde_json::json!({
                "token": jwt,
                "access_token": jwt,
                "expires_in": 900,
                "issued_at": at,
            });
            (StatusCode::OK, axum::Json(body)).into_response()
        }
        Err(auth::Denied::Broken(reason)) => {
            tracing::error!(reason = reason.as_str(), "a token could not be issued");
            StatusCode::INTERNAL_SERVER_ERROR.into_response()
        }
        Err(auth::Denied::Challenge) => {
            let mut response = (StatusCode::UNAUTHORIZED, "incorrect username or password").into_response();
            if let Ok(value) = axum::http::HeaderValue::from_str("Basic realm=\"Registry Realm\"") {
                response
                    .headers_mut()
                    .insert(axum::http::header::WWW_AUTHENTICATE, value);
            }
            response
        }
    }
}

/// `GET /auth/jwks.json`: the key that signed those tokens, so anything else
/// can check them.
async fn key_set() -> axum::response::Response {
    match local_issuer() {
        Some(issuer) => (
            StatusCode::OK,
            [(axum::http::header::CONTENT_TYPE, "application/jwk-set+json")],
            issuer.jwks(),
        )
            .into_response(),
        None => (StatusCode::NOT_FOUND, "this registry does not issue tokens").into_response(),
    }
}

/// Who a registry write is recorded as when no login is configured.
const ANONYMOUS: &str = "anonymous";

/// The login the module started with (see [`OciRegistryModule::start`]).
static LOGIN: std::sync::OnceLock<Option<Login>> = std::sync::OnceLock::new();

/// `auth.htpasswd.path` and `.realm`, from the registry configuration or else
/// the reference's environment names. `Ok(None)`: no login configured.
///
/// # Errors
///
/// A login is asked for without its path or realm, as the reference refuses
/// it, or the file cannot be created.
pub fn login_from_settings() -> crate::error::Result<Option<Login>> {
    if let Some(token) = token_from_settings()? {
        return Ok(Some(Login::Token(Arc::new(token))));
    }
    Ok(password_from_settings()?.map(|file| Login::Password(Arc::new(file))))
}

/// `auth.token`: the reference's keys, and `local` for a registry that issues
/// its own. `Ok(None)`: no token login configured.
///
/// # Errors
///
/// A key of the set is missing, or the key set or signing key cannot be read.
fn token_from_settings() -> crate::error::Result<Option<token::TokenAuth>> {
    let Some(settings) = crate::registry_compat::installed() else {
        return Ok(None);
    };
    let asked = settings
        .values
        .keys()
        .any(|key| key.starts_with("auth.token."));
    if !asked {
        return Ok(None);
    }
    let refuse = |what: &str| {
        crate::error::LiveError::Config(format!(
            "auth.token: \"{what}\" must be set for token access controller"
        ))
    };
    let realm = settings.get("auth.token.realm").ok_or_else(|| refuse("realm"))?.to_owned();
    let service = settings.get("auth.token.service").ok_or_else(|| refuse("service"))?.to_owned();
    let issuer = settings.get("auth.token.issuer").ok_or_else(|| refuse("issuer"))?.to_owned();
    let bad = |what: &str, error: &dyn std::fmt::Display| {
        crate::error::LiveError::Config(format!("auth.token.{what}: {error}"))
    };
    if settings.flag("auth.token.local").unwrap_or(false) {
        // The passwords that decide what a token may carry, and a signing key
        // kept beside the volume's other state.
        let passwords = password_from_settings()?.map(Arc::new);
        let key = crate::registry_compat::state_dir().join("registry-token-key.der");
        return token::TokenAuth::local(realm, service, issuer, &key, passwords)
            .map(Some)
            .map_err(|error| bad("local", &error));
    }
    let jwks = settings.get("auth.token.jwks").ok_or_else(|| refuse("jwks"))?;
    token::TokenAuth::validating(realm, service, issuer, std::path::Path::new(jwks))
        .map(Some)
        .map_err(|error| bad("jwks", &error))
}

/// `auth.htpasswd.path` and `.realm`.
///
/// # Errors
///
/// As [`login_from_settings`].
fn password_from_settings() -> crate::error::Result<Option<auth::Htpasswd>> {
    let (asked, path, realm) = if let Some(settings) = crate::registry_compat::installed() {
        (
            settings
                .values
                .keys()
                .any(|key| key == "auth.htpasswd" || key.starts_with("auth.htpasswd.")),
            settings.get("auth.htpasswd.path").map(str::to_owned),
            settings.get("auth.htpasswd.realm").map(str::to_owned),
        )
    } else {
        let path = std::env::var("REGISTRY_AUTH_HTPASSWD_PATH").ok();
        let realm = std::env::var("REGISTRY_AUTH_HTPASSWD_REALM").ok();
        let selector =
            std::env::var("REGISTRY_AUTH").is_ok_and(|value| value.trim() == "htpasswd");
        (selector || path.is_some() || realm.is_some(), path, realm)
    };
    if !asked {
        return Ok(None);
    }
    let refuse = |what: &str| {
        crate::error::LiveError::Config(format!(
            "auth.htpasswd: \"{what}\" must be set for htpasswd access controller"
        ))
    };
    let realm = realm.ok_or_else(|| refuse("realm"))?;
    let path = path.ok_or_else(|| refuse("path"))?;
    auth::Htpasswd::open(std::path::PathBuf::from(&path), realm)
        .map(Some)
        .map_err(|error| crate::error::LiveError::Config(format!("auth.htpasswd.path {path}: {error}")))
}

/// The reference's settings that change what a route answers. P5 reads them
/// from `config.yml` too; the environment names are the reference's own.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Settings {
    /// `storage.delete.enabled`. Off by default, as in the reference.
    pub delete_enabled: bool,
    /// `http.headers`: added to every answer under `/v2/`, errors and
    /// preflights included. It is the reference's recipe for CORS, which a web
    /// UI on another origin needs (FR-R31): `Access-Control-Allow-Origin`,
    /// `-Methods`, `-Headers`, and `-Expose-Headers` naming
    /// `Docker-Content-Digest` and `Link`. P5 fills it from `config.yml`.
    pub headers: Vec<(axum::http::HeaderName, HeaderValue)>,
    /// `storage.maintenance.readonly.enabled`: writes answer 405, as the
    /// reference's handlers leave their write methods unregistered.
    pub read_only: bool,
    /// `http.relativeurls`: `Location` is the path alone.
    pub relative_urls: bool,
    /// `http.host`, as `scheme://host[:port]`: what an absolute `Location` is
    /// built on, in place of the request's own host.
    pub host: Option<String>,
    /// `storage.maintenance.minfreespace`: a write that would leave the volume
    /// with less room than this is refused before it starts. Not a reference
    /// setting; unset is the reference's behaviour, which is to write until
    /// the disk is full.
    pub min_free_bytes: Option<u64>,
}

impl Settings {
    /// From the registry configuration the server started with, or else from
    /// the reference's environment variables.
    pub fn current() -> Self {
        let Some(settings) = crate::registry_compat::installed() else {
            return Self::from_environment();
        };
        let headers = settings
            .section("http.headers")
            .into_iter()
            .filter_map(|(name, value)| {
                let name = axum::http::HeaderName::from_bytes(name.as_bytes()).ok()?;
                // Checked when the settings were loaded; a list is one comma-joined value.
                let value = HeaderValue::from_str(crate::registry_compat::header_value(value)).ok()?;
                Some((name, value))
            })
            .collect();
        Self {
            delete_enabled: settings.flag("storage.delete.enabled").unwrap_or(false),
            headers,
            read_only: settings.flag("storage.maintenance.readonly.enabled").unwrap_or(false),
            relative_urls: settings.flag("http.relativeurls").unwrap_or(false),
            host: settings.get("http.host").and_then(crate::registry_compat::host_origin),
            min_free_bytes: settings
                .get("storage.maintenance.minfreespace")
                .and_then(crate::registry_compat::byte_size),
        }
    }

    pub fn from_environment() -> Self {
        let on = |name: &str| {
            std::env::var(name).is_ok_and(|value| value.trim().eq_ignore_ascii_case("true"))
        };
        Self {
            delete_enabled: on("REGISTRY_STORAGE_DELETE_ENABLED"),
            headers: Vec::new(),
            read_only: on("REGISTRY_STORAGE_MAINTENANCE_READONLY_ENABLED"),
            relative_urls: on("REGISTRY_HTTP_RELATIVEURLS"),
            host: std::env::var("REGISTRY_HTTP_HOST")
                .ok()
                .as_deref()
                .and_then(crate::registry_compat::host_origin),
            min_free_bytes: std::env::var("REGISTRY_STORAGE_MAINTENANCE_MINFREESPACE")
                .ok()
                .as_deref()
                .and_then(crate::registry_compat::byte_size),
        }
    }
}

pub struct OciRegistryModule;

impl LiveModule for OciRegistryModule {
    fn descriptor(&self) -> &'static ModuleDescriptor {
        &DESCRIPTOR
    }

    fn router(&self) -> Router<AppState> {
        // No `.fallback(…)`: tonic's router carries one and the merge would
        // collide. The catch-all route makes it unnecessary.
        Router::new()
            .route("/v2", any(without_the_slash))
            .route("/v2/", any(dispatch))
            .route("/v2/{*rest}", any(dispatch))
            .layer(middleware::from_fn(envelope))
            // The token endpoints, when this registry issues its own. They
            // are outside the `/v2/` envelope: a token server answers in its
            // own shape, which is what clients expect at a realm.
            .route("/auth/token", axum::routing::get(issue_token))
            .route("/auth/jwks.json", axum::routing::get(key_set))
    }

    fn authenticates_itself(&self) -> bool {
        true
    }

    /// Open the login before the listener binds: a login that cannot work
    /// stops the start, as the reference's does.
    fn start<'a>(&'a self, _context: &'a crate::module::ModuleContext) -> crate::module::ModuleStartFuture<'a> {
        Box::pin(async {
            if LOGIN.get().is_none() {
                let _ = LOGIN.set(login_from_settings()?);
            }
            Ok(())
        })
    }

    /// Into the server's one document: `/openapi.json` and `/docs` exist already.
    fn openapi(&self) -> utoipa::openapi::OpenApi {
        openapi::document()
    }
}

/// What the server's `authenticate` layer does for every other module, minus
/// the bearer check: a request id and a request span. Then the header every
/// response under `/v2/` carries, errors included.
async fn envelope(request: Request, next: Next) -> Response {
    let span = tracing::info_span!(
        "live.server.request",
        request_id = crate::server::next_request_id(),
        method = %request.method(),
        path = %request.uri().path()
    );
    let mut response = next.run(request).instrument(span).await;
    respond::stamp_version(response.headers_mut());
    response
}

/// `/v2` is not the base route; the reference's router redirects to it.
async fn without_the_slash() -> Response {
    // Byte for byte what the reference's router sends (gate B, `base`).
    let mut response = (StatusCode::MOVED_PERMANENTLY, "<a href=\"/v2/\">Moved Permanently</a>.\n\n").into_response();
    let headers = response.headers_mut();
    headers.insert(LOCATION, HeaderValue::from_static("/v2/"));
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("text/html; charset=utf-8"));
    response
}

async fn dispatch(State(state): State<AppState>, request: Request) -> Response {
    match state.oci_store() {
        Some(store) => {
            static SETTINGS: std::sync::OnceLock<Settings> = std::sync::OnceLock::new();
            // Set by the module's start. Unset would be a registry serving
            // before it knows whether it has a login: fail closed.
            let Some(login) = LOGIN.get() else {
                return OciError::internal(&"the registry module was not started").into_response();
            };
            let registry = Registry {
                store: store.clone(),
                settings: SETTINGS.get_or_init(Settings::current).clone(),
                audit: Some(state.audit().clone()),
                login: login.clone(),
            };
            handle(registry, request).await
        }
        // The volume is opened whenever the module is enabled, so this is a
        // defect, not a state a client can cause.
        None => OciError::internal(&"the registry module is enabled without a volume").into_response(),
    }
}

/// Answer one request under `/v2/`.
pub async fn handle(registry: Registry, request: Request) -> Response {
    // The body is not `Sync`, so nothing borrowed from the whole request may
    // live across an await: the head is borrowed, the body is moved.
    let (head, body) = request.into_parts();
    // As the reference's URL builder: relative when asked, else on
    // `http.host` when set, else on the request's own host.
    let origin = if registry.settings.relative_urls {
        None
    } else {
        registry.settings.host.clone().or_else(|| origin(&head))
    };
    let configured = registry.settings.headers.clone();
    let audit = registry.audit.clone();
    let rest = head.uri.path().strip_prefix("/v2/").unwrap_or_default();
    let decoded = path::decode(rest);
    let route = decoded
        .as_deref()
        .ok_or_else(OciError::unknown_route)
        .and_then(|rest| path::parse(&head.method, rest));
    let in_flight = metrics::start(handler_name(route.as_ref().ok()), &head.method);
    // While a health check fails, every request is 503 UNAVAILABLE, as the
    // reference's health.Handler answers: that is what `/debug/health/down`
    // drains.
    if debug::failing() {
        let mut response = OciError::new(ErrorCode::Unavailable)
            .with_detail(serde_json::json!("health check failed: please see /debug/health"))
            .into_response();
        in_flight.done(response.status().as_u16());
        for (name, value) in configured {
            response.headers_mut().append(name, value);
        }
        return response;
    }
    // As the reference: whatever its router matches is authorized before
    // anything else about it (method, digest, upload id). Only a path with
    // no route, the plain 404, is answered without a login.
    // A 405 carries no code either (the router's plain text), so the test is
    // the status: only the plain 404 means no route matched.
    let routed = match &route {
        Ok(_) => true,
        Err(error) => error.code().is_some() || error.status() != StatusCode::NOT_FOUND,
    };
    let scope = decoded.as_deref().and_then(path::Scope::of).filter(|_| routed);
    let mut principal = ANONYMOUS.to_owned();
    let denied = match (&registry.login, &scope) {
        (Some(login), Some(scope)) => match login
            .authenticate(&head.headers, &head.method, scope, head.uri.query())
            .await
        {
            Ok(user) => {
                principal = user;
                None
            }
            Err(denied) => Some(login.refuse(&denied, &head.method, scope, head.uri.query())),
        },
        _ => None,
    };
    let (mut response, record) = match (denied, route) {
        (Some(refused), _) => (refused, None),
        (None, Ok(route)) => {
            let audited = audited(&route);
            let result = serve(registry, route, &head, body).await;
            let outcome = match &result {
                Ok(_) => "accepted".to_owned(),
                Err(error) => format!("error:{}", error.code().map_or("NOT_FOUND", ErrorCode::as_str)),
            };
            let response = result.unwrap_or_else(IntoResponse::into_response);
            let record = audited.and_then(|audited| audited.resolve(&response, outcome));
            (response, record)
        }
        (None, Err(error)) => (error.into_response(), None),
    };
    if let (Some(audit), Some((operation, resource, outcome))) = (audit, record) {
        // Off the response path: the answer does not wait for the log's one
        // writer, and a client that goes away cannot drop the record of a
        // write that has already happened.
        let event = crate::audit::AuditEvent::new(&principal, operation, Some(resource), outcome);
        tokio::spawn(async move {
            if let Err(error) = audit.record(event).await {
                tracing::error!(%error, "failed to record a registry audit event");
            }
        });
    }
    absolute_location(&mut response, origin.as_deref());
    in_flight.done(response.status().as_u16());
    // Last, so they are on errors and on `OPTIONS` too. A browser's preflight
    // carries no credentials: when login lands (P6) `OPTIONS` stays in front
    // of it, or no web UI on another origin can reach the registry.
    for (name, value) in configured {
        response.headers_mut().append(name, value);
    }
    response
}

/// The route's name for `/metrics` (`contracts/registry-api.md`): never the
/// raw path, so no repository name becomes a label value.
fn handler_name(route: Option<&Route>) -> &'static str {
    match route {
        Some(Route::Base) => "base",
        Some(Route::Catalog) => "catalog",
        Some(Route::TagsList { .. }) => "tags",
        Some(Route::Manifest { .. }) => "manifest",
        Some(Route::Blob { .. }) => "blob",
        // The reference's route names (`routes.go`), so its dashboards draw.
        Some(Route::UploadStart { .. }) => "blob-upload",
        Some(Route::Upload { .. }) => "blob-upload-chunk",
        Some(Route::Referrers { .. }) => "referrers",
        Some(Route::Options { .. }) => "options",
        None => "none",
    }
}

/// A write the audit log records: the operation, and what it acted on.
struct Audited {
    operation: &'static str,
    resource: String,
    /// `POST …/uploads/` writes only when it answers 201 (a one-request
    /// upload, or a mount); a 202 opens a session and changes nothing.
    only_when_created: bool,
}

impl Audited {
    /// The record, or `None` for a request that turned out to change nothing.
    fn resolve(self, response: &Response, outcome: String) -> Option<(&'static str, String, String)> {
        let created = response.status() == StatusCode::CREATED;
        if self.only_when_created && !created && outcome == "accepted" {
            return None;
        }
        // What was stored is named by the answer's digest: a blob's is known
        // only once it is stored, and a tag push records what the tag now names.
        let stored = response
            .headers()
            .get("docker-content-digest")
            .and_then(|value| value.to_str().ok());
        let resource = match stored {
            Some(digest) if created && !self.resource.contains('@') => {
                format!("{}@{digest}", self.resource)
            }
            _ => self.resource,
        };
        Some((self.operation, resource, outcome))
    }
}

/// `repo:tag` or `repo@digest`, as image references are written.
fn named(repo: &crate::oci_store::RepoName, reference: &crate::oci_store::Reference) -> String {
    match reference {
        crate::oci_store::Reference::Tag(tag) => format!("{repo}:{tag}"),
        crate::oci_store::Reference::Digest(digest) => format!("{repo}@{digest}"),
    }
}

/// The routes that write, named as the server names its operations. Reads are
/// not recorded, as the server records none of its own.
fn audited(route: &Route) -> Option<Audited> {
    let (operation, resource, only_when_created) = match route {
        Route::Manifest {
            repo,
            reference,
            verb: ManifestVerb::Put,
        } => ("oci.manifest.put", named(repo, reference), false),
        Route::Manifest {
            repo,
            reference,
            verb: ManifestVerb::Delete,
        } => ("oci.manifest.delete", named(repo, reference), false),
        Route::Blob {
            repo,
            digest,
            verb: BlobVerb::Delete,
        } => ("oci.blob.delete", format!("{repo}@{digest}"), false),
        Route::Upload {
            repo,
            verb: UploadVerb::Put,
            ..
        } => ("oci.blob.put", repo.to_string(), false),
        Route::UploadStart { repo } => ("oci.blob.put", repo.to_string(), true),
        _ => return None,
    };
    Some(Audited {
        operation,
        resource,
        only_when_created,
    })
}

/// `scheme://host` as the client addressed us. `None` without a `Host`.
fn origin(head: &axum::http::request::Parts) -> Option<String> {
    let headers = &head.headers;
    // HTTP/2 carries the host in `:authority`, which Go reads as `r.Host` too.
    let host = headers
        .get(axum::http::header::HOST)
        .and_then(|value| value.to_str().ok())
        .or_else(|| head.uri.authority().map(axum::http::uri::Authority::as_str))?;
    // As Go's URL builder: https when the request came over TLS, and a
    // proxy's X-Forwarded-Proto over either.
    let direct = if head.extensions.get::<crate::tls::ServedOverTls>().is_some() {
        "https"
    } else {
        "http"
    };
    let scheme = headers
        .get("x-forwarded-proto")
        .and_then(|value| value.to_str().ok())
        .filter(|scheme| *scheme == "https" || *scheme == "http")
        .unwrap_or(direct);
    Some(format!("{scheme}://{host}"))
}

/// The reference answers `Location` as an absolute URL unless
/// `http.relativeurls` is set (gate B, every push scenario). The routes build
/// paths; this makes them what the reference sends.
fn absolute_location(response: &mut Response, origin: Option<&str>) {
    let Some(origin) = origin else { return };
    let absolute = response
        .headers()
        .get(LOCATION)
        .and_then(|value| value.to_str().ok())
        .filter(|path| path.starts_with('/'))
        .and_then(|path| HeaderValue::from_str(&format!("{origin}{path}")).ok());
    if let Some(absolute) = absolute {
        response.headers_mut().insert(LOCATION, absolute);
    }
}

async fn serve(
    registry: Registry,
    route: Route,
    head: &axum::http::request::Parts,
    body: Body,
) -> Result<Response, OciError> {
    let (headers, query) = (&head.headers, head.uri.query());
    let Registry {
        store, settings, ..
    } = registry;
    let route = if settings.read_only {
        read_only(&store, route).await?
    } else {
        route
    };
    // A volume with no room left fails a push somewhere in the middle, and the
    // client cannot tell that from a fault of its own. Refuse it at the door,
    // while reads go on (`storage.maintenance.minfreespace`).
    if let Some(floor) = settings.min_free_bytes {
        if writes(&route) {
            let store = store.clone();
            let free = tokio::task::spawn_blocking(move || store.free_space())
                .await
                .map_err(|error| OciError::internal(&error))?
                .map_err(|error| OciError::internal(&error))?;
            if free < floor {
                tracing::warn!(free, floor, "a write was refused: the volume is nearly full");
                return Err(OciError::new(ErrorCode::Denied).with_detail(serde_json::json!(
                    format!("the volume has {free} bytes free, under the {floor} this registry keeps in reserve")
                )));
            }
        }
    }
    match route {
        Route::Base => Ok(json(StatusCode::OK, "{}")),
        Route::Options { allow } => {
            let mut response = Response::new(Body::empty());
            response
                .headers_mut()
                .insert(ALLOW, HeaderValue::from_static(allow));
            Ok(response)
        }
        Route::Blob {
            repo,
            digest,
            verb: verb @ (BlobVerb::Get | BlobVerb::Head),
        } => blobs::get(store, repo, digest, headers, verb == BlobVerb::Head).await,
        Route::Manifest {
            repo,
            reference,
            verb: verb @ (ManifestVerb::Get | ManifestVerb::Head),
        } => manifests::get(store, repo, reference, headers, verb == ManifestVerb::Head).await,
        Route::Manifest {
            repo,
            reference,
            verb: ManifestVerb::Put,
        } => manifests::put(store, repo, reference, headers, body).await,
        Route::UploadStart { repo } => uploads::start(store, repo, query, body).await,
        Route::Upload { repo, id, verb } => match verb {
            UploadVerb::Status => uploads::status(store, repo, id).await,
            UploadVerb::Patch => uploads::patch(store, repo, id, headers, body).await,
            UploadVerb::Put => uploads::put(store, repo, id, query, body).await,
            UploadVerb::Delete => uploads::cancel(store, repo, id).await,
        },
        Route::Catalog => listing::catalog(store, query).await,
        Route::TagsList { repo } => listing::tags(store, repo, query).await,
        Route::Referrers { repo, digest } => listing::referrers(store, repo, digest, query).await,
        // Off unless `storage.delete.enabled`, as in the reference.
        Route::Manifest { .. } | Route::Blob { .. } if !settings.delete_enabled => {
            Err(OciError::new(ErrorCode::Unsupported))
        }
        Route::Manifest {
            repo, reference, ..
        } => delete::manifest(store, repo, reference).await,
        Route::Blob { repo, digest, .. } => delete::blob(store, repo, digest).await,
    }
}

/// Read-only mode, as the reference's dispatchers build it: the write methods
/// are not registered, so the router answers 405 naming `GET, HEAD`. A write
/// to an upload id tries to resume the upload first, so an unknown id is
/// `BLOB_UPLOAD_UNKNOWN` before it is a wrong method (`blobupload.go`).
async fn read_only(store: &Arc<OciStore>, route: Route) -> Result<Route, OciError> {
    const READS: &str = "GET, HEAD";
    match route {
        Route::Options { allow } => Ok(Route::Options {
            allow: path::read_only_allow(allow),
        }),
        Route::Manifest {
            verb: ManifestVerb::Put | ManifestVerb::Delete,
            ..
        }
        | Route::Blob {
            verb: BlobVerb::Delete,
            ..
        }
        | Route::UploadStart { .. } => Err(OciError::wrong_method(READS)),
        Route::Upload { id, verb, .. } if verb != UploadVerb::Status => {
            let store = store.clone();
            let known = tokio::task::spawn_blocking(move || store.upload_status(&id).is_ok())
                .await
                .map_err(|error| OciError::internal(&error))?;
            Err(if known {
                OciError::wrong_method(READS)
            } else {
                OciError::upload_unknown()
            })
        }
        other => Ok(other),
    }
}

/// Whether this route writes: what the free-space floor refuses.
fn writes(route: &Route) -> bool {
    matches!(
        route,
        Route::UploadStart { .. }
            | Route::Upload {
                verb: UploadVerb::Patch | UploadVerb::Put,
                ..
            }
            | Route::Manifest {
                verb: ManifestVerb::Put,
                ..
            }
    )
}

fn json(status: StatusCode, body: &'static str) -> Response {
    let mut response = Response::new(Body::from(body));
    *response.status_mut() = status;
    let headers = response.headers_mut();
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    headers.insert(CONTENT_LENGTH, HeaderValue::from(body.len()));
    response
}


/// A manifest the reference stored, checked as a push of it would be, for
/// `OciStore::import`: its media type, and what the store must find linked.
///
/// # Errors
///
/// The reason a push of these bytes would be refused.
pub fn import_plan(
    media_type: &str,
    bytes: &[u8],
) -> Result<(String, crate::oci_store::ManifestPlan), String> {
    media::plan(Some(media_type), bytes).map_err(|error| error.reason())
}

#[cfg(test)]
mod tests {
    use super::origin;

    fn head(uri: &str, host: Option<&str>, tls: bool, forwarded: Option<&str>) -> axum::http::request::Parts {
        let mut builder = axum::http::Request::builder().uri(uri);
        if let Some(host) = host {
            builder = builder.header("host", host);
        }
        if let Some(scheme) = forwarded {
            builder = builder.header("x-forwarded-proto", scheme);
        }
        let (mut parts, ()) = builder.body(()).expect("request").into_parts();
        if tls {
            parts.extensions.insert(crate::tls::ServedOverTls);
        }
        parts
    }

    /// As Go's URL builder: the host from `Host`, or from HTTP/2's
    /// `:authority`; https over TLS; a proxy's `X-Forwarded-Proto` over both.
    #[test]
    fn location_origin_follows_the_connection_as_the_reference_does() {
        assert_eq!(origin(&head("/v2/", Some("r:5000"), false, None)).as_deref(), Some("http://r:5000"));
        assert_eq!(origin(&head("/v2/", Some("r:5000"), true, None)).as_deref(), Some("https://r:5000"));
        assert_eq!(origin(&head("https://r:5000/v2/", None, true, None)).as_deref(), Some("https://r:5000"), "HTTP/2");
        assert_eq!(origin(&head("/v2/", Some("r"), true, Some("http"))).as_deref(), Some("http://r"));
        assert_eq!(origin(&head("/v2/", None, false, None)), None);
    }
}
