//! OpenAI-compatible HTTP API.
//!
//! A thin translation layer over the Phase-1 inference core: chat messages
//! render to the same `role: content` transcript the native chat module uses,
//! and completions come from the configured [`InferenceEngine`]. `stream:
//! true` is accepted by every engine — natively where the engine supports
//! it, emulated (a completed response replayed as deltas) otherwise — and
//! the `x-hologram-stream` response header discloses which one happened.

use crate::app::AppState;
use crate::error::LiveError;
use crate::inference::{CompletionEvent, CompletionRequest, InferenceEngine};
use crate::models::{ModelCatalog, ModelInfo};
use crate::module::{LiveModule, ModuleDescriptor};
use axum::extract::State;
use axum::http::StatusCode;
use axum::response::sse::{Event, KeepAlive, Sse};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use utoipa::ToSchema;

static DESCRIPTOR: ModuleDescriptor = ModuleDescriptor {
    id: "dev.hologram.live.openai-compat",
    name: "OpenAI-Compatible API",
    version: env!("CARGO_PKG_VERSION"),
    dependencies: &["dev.hologram.live.inference"],
    operations: &[],
};

pub struct OpenAiCompatModule;

impl LiveModule for OpenAiCompatModule {
    fn descriptor(&self) -> &'static ModuleDescriptor {
        &DESCRIPTOR
    }

    fn router(&self) -> Router<AppState> {
        Router::new()
            .route("/v1/chat/completions", post(chat_completions))
            .route("/v1/models", get(list_models))
    }

    fn openapi(&self) -> utoipa::openapi::OpenApi {
        <OpenAiApiDoc as utoipa::OpenApi>::openapi()
    }
}

#[derive(Debug, Deserialize, ToSchema)]
pub struct ChatCompletionRequest {
    /// Catalog model id or name; falls back to `inference.default_model`.
    #[serde(default)]
    pub model: String,
    pub messages: Vec<ChatMessage>,
    #[serde(default)]
    pub max_tokens: Option<u32>,
    #[serde(default)]
    pub temperature: Option<f32>,
    #[serde(default)]
    pub seed: Option<u64>,
    #[serde(default)]
    pub stream: Option<bool>,
    #[serde(default)]
    pub stream_options: Option<StreamOptions>,
}

#[derive(Debug, Clone, Serialize, Deserialize, ToSchema)]
pub struct ChatMessage {
    pub role: String,
    pub content: String,
}

#[derive(Debug, Default, Deserialize, ToSchema)]
pub struct StreamOptions {
    /// Adds a usage-bearing chunk with empty `choices` before `[DONE]`. The
    /// only standard way a streaming client can obtain counts.
    #[serde(default)]
    pub include_usage: bool,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ChatCompletionChunk {
    pub id: String,
    pub object: String,
    pub created: u64,
    pub model: String,
    pub choices: Vec<ChunkChoice>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub usage: Option<Usage>,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ChunkChoice {
    pub index: u32,
    pub delta: ChunkDelta,
    pub finish_reason: Option<String>,
}

#[derive(Debug, Default, Serialize, ToSchema)]
pub struct ChunkDelta {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub role: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content: Option<String>,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ChatCompletion {
    pub id: String,
    pub object: String,
    pub created: u64,
    pub model: String,
    pub choices: Vec<ChatChoice>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub usage: Option<Usage>,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ChatChoice {
    pub index: u32,
    pub message: ChatMessage,
    pub finish_reason: String,
}

/// Present only when the engine measured both halves (D3). Absence reads as
/// not-measured; `0` would assert a measurement no engine made.
#[derive(Debug, Serialize, ToSchema)]
pub struct Usage {
    pub prompt_tokens: u64,
    pub completion_tokens: u64,
    pub total_tokens: u64,
}

impl From<crate::inference::TokenUsage> for Usage {
    fn from(usage: crate::inference::TokenUsage) -> Self {
        Self {
            prompt_tokens: usage.prompt_tokens,
            completion_tokens: usage.completion_tokens,
            total_tokens: usage.total(),
        }
    }
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ModelList {
    pub object: String,
    pub data: Vec<ModelObject>,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct ModelObject {
    pub id: String,
    pub object: String,
    pub created: u64,
    pub owned_by: String,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct OpenAiErrorEnvelope {
    pub error: OpenAiErrorBody,
}

#[derive(Debug, Serialize, ToSchema)]
pub struct OpenAiErrorBody {
    pub message: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub code: Option<String>,
}

/// Error rendered in the `OpenAI` envelope rather than the native `ApiError`.
#[derive(Debug)]
pub struct OpenAiError {
    status: StatusCode,
    pub(crate) body: OpenAiErrorBody,
}

impl OpenAiError {
    fn invalid_request(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            body: OpenAiErrorBody {
                message: message.into(),
                kind: "invalid_request_error".to_owned(),
                code: None,
            },
        }
    }

    fn not_found(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::NOT_FOUND,
            body: OpenAiErrorBody {
                message: message.into(),
                kind: "not_found_error".to_owned(),
                code: None,
            },
        }
    }

    fn server(error: &LiveError) -> Self {
        Self {
            status: StatusCode::INTERNAL_SERVER_ERROR,
            body: OpenAiErrorBody {
                message: error.to_string(),
                kind: "server_error".to_owned(),
                code: Some(error.code().to_owned()),
            },
        }
    }
}

impl From<LiveError> for OpenAiError {
    fn from(error: LiveError) -> Self {
        match error {
            LiveError::NotFound(_) => {
                let mut mapped = Self::not_found(error.to_string());
                mapped.body.code = Some(error.code().to_owned());
                mapped
            }
            LiveError::Config(_) | LiveError::Protocol(_) | LiveError::InvalidHolo(_) => {
                let mut mapped = Self::invalid_request(error.to_string());
                mapped.body.code = Some(error.code().to_owned());
                mapped
            }
            _ => Self::server(&error),
        }
    }
}

impl IntoResponse for OpenAiError {
    fn into_response(self) -> Response {
        (self.status, Json(OpenAiErrorEnvelope { error: self.body })).into_response()
    }
}

#[derive(utoipa::OpenApi)]
#[openapi(
    paths(chat_completions, list_models),
    components(schemas(
        ChatCompletionRequest,
        ChatMessage,
        ChatCompletion,
        ChatChoice,
        Usage,
        StreamOptions,
        ChatCompletionChunk,
        ChunkChoice,
        ChunkDelta,
        ModelList,
        ModelObject,
        OpenAiErrorEnvelope,
        OpenAiErrorBody
    )),
    tags((name = "openai-compat", description = "OpenAI-compatible API"))
)]
struct OpenAiApiDoc;

#[utoipa::path(
    post,
    path = "/v1/chat/completions",
    request_body = ChatCompletionRequest,
    responses(
        (status = 200, description = "`stream` omitted or `false` returns one JSON `ChatCompletion`. `stream: true` returns `text/event-stream` of `ChatCompletionChunk` frames as `data: {...}` lines, terminated by `data: [DONE]`. A mid-stream engine failure is reported as one `data:` frame carrying `OpenAiErrorEnvelope`, still followed by `data: [DONE]`, since the status is already 200 by the time streaming starts.", content(
            (ChatCompletion = "application/json"),
            (ChatCompletionChunk = "text/event-stream")
        ), headers(
            ("x-hologram-stream" = String, description = "`native` when the engine produced deltas as it generated them, or `emulated` when the daemon completed the request first and replayed the result as deltas. Present on both streaming and non-streaming responses.")
        )),
        (status = 400, body = OpenAiErrorEnvelope),
        (status = 404, body = OpenAiErrorEnvelope)
    )
)]
pub async fn chat_completions(
    State(state): State<AppState>,
    Json(request): Json<ChatCompletionRequest>,
) -> Result<Response, OpenAiError> {
    let engine = state.chat().engine().clone();
    let catalog = state.models().clone();
    let default_model = state.config().inference.default_model.clone();
    dispatch_chat_completions(engine, catalog, &default_model, request).await
}

/// Chooses the streaming or buffered path for `/v1/chat/completions`, kept
/// free of `AppState` so unit tests can drive it with a bare engine and
/// catalog. Deleting the `stream == Some(true)` branch here silently reverts
/// the endpoint to buffered-only while every other test stays green, which is
/// why this dispatch is exercised directly rather than only through
/// `complete_chat`/`stream_chat`.
async fn dispatch_chat_completions(
    engine: Arc<dyn InferenceEngine>,
    catalog: Arc<ModelCatalog>,
    default_model: &str,
    request: ChatCompletionRequest,
) -> Result<Response, OpenAiError> {
    if request.stream == Some(true) {
        return stream_chat(engine, catalog, default_model, request).await;
    }
    // Captured before `complete_chat` consumes `engine`: the header must
    // name the engine that served the request regardless of mode, matching
    // the streaming path's `x-hologram-stream` marker (README.md).
    let kind = engine.stream_kind();
    let completion = complete_chat(engine, catalog, default_model, request).await?;
    let mut response = Json(completion).into_response();
    response.headers_mut().insert(
        "x-hologram-stream",
        axum::http::HeaderValue::from_static(kind.header_value()),
    );
    Ok(response)
}

#[utoipa::path(
    get,
    path = "/v1/models",
    responses((status = 200, body = ModelList))
)]
pub async fn list_models(State(state): State<AppState>) -> Result<Json<ModelList>, OpenAiError> {
    let catalog = state.models().clone();
    let engine = state.chat().engine().clone();
    let models = super::model_inventory::list(catalog, engine)
        .await
        .map_err(OpenAiError::from)?;
    Ok(Json(model_list(models)))
}

/// Core request mapping, kept free of `AppState` so unit tests can drive it
/// with a bare engine and catalog.
async fn complete_chat(
    engine: Arc<dyn InferenceEngine>,
    catalog: Arc<ModelCatalog>,
    default_model: &str,
    request: ChatCompletionRequest,
) -> Result<ChatCompletion, OpenAiError> {
    if request.stream == Some(true) {
        return Err(OpenAiError::invalid_request(
            "streaming is not supported; omit stream or send stream: false",
        ));
    }
    if request.messages.is_empty() {
        return Err(OpenAiError::invalid_request("messages must not be empty"));
    }
    let model = resolve_model(&engine, &catalog, default_model, &request.model).await?;
    let completion = engine
        .complete(CompletionRequest {
            prompt: render_prompt(&request.messages),
            max_tokens: request.max_tokens,
            temperature: request.temperature,
            seed: request.seed,
            session_key: None,
        })
        .await
        .map_err(OpenAiError::from)?;
    let created = unix_seconds();
    Ok(ChatCompletion {
        id: completion_id(created, &completion.text),
        object: "chat.completion".to_owned(),
        created,
        model,
        choices: vec![ChatChoice {
            index: 0,
            message: ChatMessage {
                role: "assistant".to_owned(),
                content: completion.text,
            },
            finish_reason: "stop".to_owned(),
        }],
        usage: completion.usage.map(Usage::from),
    })
}

/// Streaming half of `chat_completions`, kept free of `AppState` so tests can
/// drive it with a bare engine and catalog.
async fn stream_chat(
    engine: Arc<dyn InferenceEngine>,
    catalog: Arc<ModelCatalog>,
    default_model: &str,
    request: ChatCompletionRequest,
) -> Result<Response, OpenAiError> {
    if request.messages.is_empty() {
        return Err(OpenAiError::invalid_request("messages must not be empty"));
    }
    let model = resolve_model(&engine, &catalog, default_model, &request.model).await?;
    let kind = engine.stream_kind();
    let include_usage = request
        .stream_options
        .as_ref()
        .is_some_and(|options| options.include_usage);
    let created = unix_seconds();
    let id = completion_id(created, &model);
    let events = engine
        .complete_stream(CompletionRequest {
            prompt: render_prompt(&request.messages),
            max_tokens: request.max_tokens,
            temperature: request.temperature,
            seed: request.seed,
            session_key: None,
        })
        .await
        .map_err(OpenAiError::from)?;

    let (sender, receiver) = tokio::sync::mpsc::channel(16);
    tokio::spawn(async move {
        use tokio_stream::StreamExt;

        let chunk = |choices, usage| ChatCompletionChunk {
            id: id.clone(),
            object: "chat.completion.chunk".to_owned(),
            created,
            model: model.clone(),
            choices,
            usage,
        };
        // `send` must be a macro, not a closure: async closures are unstable,
        // and `try_send` would silently truncate the stream whenever a slow
        // client let the 16-slot channel fill. `.send().await` applies
        // backpressure instead.
        macro_rules! send {
            ($value:expr) => {{
                let encoded = serde_json::to_string(&$value).unwrap_or_default();
                sender
                    .send(Ok::<_, std::convert::Infallible>(
                        Event::default().data(encoded),
                    ))
                    .await
            }};
        }

        let role = chunk(
            vec![ChunkChoice {
                index: 0,
                delta: ChunkDelta {
                    role: Some("assistant".to_owned()),
                    content: None,
                },
                finish_reason: None,
            }],
            None,
        );
        if send!(role).is_err() {
            return;
        }

        let mut events = events;
        let mut usage = None;
        while let Some(event) = events.next().await {
            match event {
                Ok(CompletionEvent::Delta(text)) => {
                    let delta = chunk(
                        vec![ChunkChoice {
                            index: 0,
                            delta: ChunkDelta {
                                role: None,
                                content: Some(text),
                            },
                            finish_reason: None,
                        }],
                        None,
                    );
                    if send!(delta).is_err() {
                        return;
                    }
                }
                Ok(CompletionEvent::Done(summary)) => {
                    // The engine contract promises `Done` is terminal, but an
                    // engine that stalls afterward instead of ending its
                    // stream would otherwise hang the client with no
                    // `[DONE]`. Breaking here enforces the guarantee rather
                    // than trusting it.
                    usage = summary.usage;
                    break;
                }
                Err(error) => {
                    // Status is already 200, so in-band is the only honest
                    // way to report this (§4). Return rather than break: a
                    // finish_reason of "stop" after a failure would claim a
                    // clean completion that did not happen.
                    let envelope = OpenAiErrorEnvelope {
                        error: OpenAiError::from(error).body,
                    };
                    let _ = send!(envelope);
                    let _ = sender.send(Ok(Event::default().data("[DONE]"))).await;
                    return;
                }
            }
        }

        let stop = chunk(
            vec![ChunkChoice {
                index: 0,
                delta: ChunkDelta::default(),
                finish_reason: Some("stop".to_owned()),
            }],
            None,
        );
        let _ = send!(stop);

        if include_usage {
            if let Some(usage) = usage {
                let final_chunk = chunk(Vec::new(), Some(Usage::from(usage)));
                let _ = send!(final_chunk);
            }
        }

        let _ = sender.send(Ok(Event::default().data("[DONE]"))).await;
    });

    let stream = tokio_stream::wrappers::ReceiverStream::new(receiver);
    // Long-idle native streams can otherwise be dropped by intermediary
    // proxies that time out on connections with no traffic.
    let mut response = Sse::new(stream).keep_alive(KeepAlive::default()).into_response();
    response.headers_mut().insert(
        "x-hologram-stream",
        axum::http::HeaderValue::from_static(kind.header_value()),
    );
    Ok(response)
}

/// Resolves the requested model to the label echoed in the response. The
/// echo engine accepts anything (it is the no-engine fallback); other engines
/// validate against the catalog, then against engine-reported models so
/// remote engine tags (e.g. Ollama's) remain usable.
async fn resolve_model(
    engine: &Arc<dyn InferenceEngine>,
    catalog: &Arc<ModelCatalog>,
    default_model: &str,
    requested: &str,
) -> Result<String, OpenAiError> {
    let name = if requested.trim().is_empty() {
        default_model.trim()
    } else {
        requested.trim()
    };
    if name.is_empty() {
        return Ok(engine.name().to_owned());
    }
    if engine.name() == "echo" {
        return Ok(name.to_owned());
    }
    let lookup = name.to_owned();
    let found = {
        let catalog = catalog.clone();
        let lookup = lookup.clone();
        tokio::task::spawn_blocking(move || catalog.resolve(&lookup))
            .await
            .map_err(|error| {
                OpenAiError::server(&LiveError::Conflict(format!("join model lookup: {error}")))
            })?
    };
    if let Ok(info) = found {
        return Ok(info.name);
    }
    let engine_models = engine.list_models().await.unwrap_or_default();
    if engine_models
        .iter()
        .any(|model| model.id == lookup || model.name == lookup)
    {
        Ok(lookup)
    } else {
        Err(OpenAiError::not_found(format!("model {name:?} not found")))
    }
}

fn model_list(models: Vec<ModelInfo>) -> ModelList {
    ModelList {
        object: "list".to_owned(),
        data: models
            .into_iter()
            .map(|model| ModelObject {
                id: model.id,
                object: "model".to_owned(),
                created: model.created_at_millis / 1000,
                owned_by: "hologram".to_owned(),
            })
            .collect(),
    }
}

/// Same `role: content` transcript shape as `chat::render_transcript`.
fn render_prompt(messages: &[ChatMessage]) -> String {
    messages
        .iter()
        .map(|message| format!("{}: {}", message.role, message.content))
        .collect::<Vec<_>>()
        .join("\n")
}

fn unix_seconds() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_secs())
}

/// Process-lifetime source of uniqueness for [`completion_id`]. Needed on
/// the streaming path, where the seed text is the model name rather than
/// response text (unknown upfront): two streaming requests for the same
/// model within the same wall-clock second would otherwise hash identically.
static NEXT_COMPLETION_SEQUENCE: AtomicU64 = AtomicU64::new(0);

fn completion_id(created: u64, text: &str) -> String {
    let sequence = NEXT_COMPLETION_SEQUENCE.fetch_add(1, Ordering::Relaxed);
    let mut hasher = blake3::Hasher::new();
    hasher.update(&created.to_le_bytes());
    hasher.update(&sequence.to_le_bytes());
    hasher.update(text.as_bytes());
    let hex = hasher.finalize().to_hex();
    format!("chatcmpl-{}", &hex[..24])
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::inference::Completion;

    struct Fixture {
        temporary: tempfile::TempDir,
        catalog: Arc<ModelCatalog>,
    }

    fn fixture() -> Fixture {
        let temporary = tempfile::tempdir().expect("temporary directory");
        let store = Arc::new(
            crate::store::ObjectStore::open(temporary.path().join("store")).expect("store"),
        );
        let catalog =
            Arc::new(ModelCatalog::open(store, temporary.path().join("models")).expect("catalog"));
        Fixture { temporary, catalog }
    }

    fn import_model(fixture: &Fixture) -> ModelInfo {
        let artifact = fixture.temporary.path().join("tiny.wcpu");
        std::fs::create_dir_all(&artifact).expect("artifact dir");
        std::fs::write(artifact.join("manifest.json"), b"{}").expect("manifest");
        fixture.catalog.import(&artifact).expect("import")
    }

    /// Replies with the prompt verbatim so tests can assert the transcript.
    struct MirrorEngine;

    #[tonic::async_trait]
    impl InferenceEngine for MirrorEngine {
        fn name(&self) -> &'static str {
            "mirror"
        }

        async fn complete(&self, request: CompletionRequest) -> crate::error::Result<Completion> {
            Ok(Completion {
                text: request.prompt,
                model: "mirror".to_owned(),
                tokens_per_second: None,
                elapsed_millis: 0,
                usage: None,
            })
        }

        async fn list_models(&self) -> crate::error::Result<Vec<ModelInfo>> {
            Ok(Vec::new())
        }
    }

    /// Streams one delta, then fails. Only a native engine can fail this way;
    /// buffered engines resolve `complete()` before the stream exists.
    struct HalfwayFailingEngine;

    #[tonic::async_trait]
    impl InferenceEngine for HalfwayFailingEngine {
        fn name(&self) -> &'static str {
            "halfway-failing"
        }

        fn stream_kind(&self) -> crate::inference::StreamKind {
            crate::inference::StreamKind::Native
        }

        async fn complete(&self, _request: CompletionRequest) -> crate::error::Result<Completion> {
            Err(LiveError::Transport("this fixture only streams".to_owned()))
        }

        async fn complete_stream(
            &self,
            _request: CompletionRequest,
        ) -> crate::error::Result<crate::inference::CompletionStream> {
            Ok(Box::pin(tokio_stream::iter(vec![
                Ok(CompletionEvent::Delta("Hel".to_owned())),
                Err(LiveError::Transport("the engine vanished".to_owned())),
            ])))
        }

        async fn list_models(&self) -> crate::error::Result<Vec<ModelInfo>> {
            Ok(Vec::new())
        }
    }

    fn request(model: &str, contents: &[&str]) -> ChatCompletionRequest {
        ChatCompletionRequest {
            model: model.to_owned(),
            messages: contents
                .iter()
                .map(|content| ChatMessage {
                    role: "user".to_owned(),
                    content: (*content).to_owned(),
                })
                .collect(),
            max_tokens: None,
            temperature: None,
            seed: None,
            stream: None,
            stream_options: None,
        }
    }

    #[tokio::test]
    async fn echo_request_maps_to_a_valid_chat_completion() {
        let fixture = fixture();
        let completion = complete_chat(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "",
            request("gpt-test", &["hello world"]),
        )
        .await
        .expect("completion");

        assert_eq!(completion.object, "chat.completion");
        assert!(completion.id.starts_with("chatcmpl-"));
        assert!(completion.created > 0);
        assert_eq!(completion.model, "gpt-test");
        assert_eq!(completion.choices.len(), 1);
        assert_eq!(completion.choices[0].index, 0);
        assert_eq!(completion.choices[0].finish_reason, "stop");
        assert_eq!(completion.choices[0].message.role, "assistant");
        assert_eq!(completion.choices[0].message.content, "hello world");
    }

    #[tokio::test]
    async fn usage_is_omitted_when_the_engine_reports_no_counts() {
        let fixture = fixture();
        let completion = complete_chat(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            request("", &["Hello"]),
        )
        .await
        .expect("the echo engine always completes");

        assert!(completion.usage.is_none(), "echo measures no tokens");
        let encoded = serde_json::to_value(&completion).expect("serialize");
        assert!(
            encoded.get("usage").is_none(),
            "an absent key reads as not-measured; null would violate the \
             declared int type"
        );
    }

    #[test]
    fn usage_carries_the_total_when_the_engine_measured_both_halves() {
        let usage = Usage::from(crate::inference::TokenUsage {
            prompt_tokens: 18,
            completion_tokens: 42,
        });
        assert_eq!(usage.prompt_tokens, 18);
        assert_eq!(usage.completion_tokens, 42);
        assert_eq!(usage.total_tokens, 60);
    }

    #[tokio::test]
    async fn messages_render_as_a_transcript_prompt() {
        let fixture = fixture();
        let mut conversation = request("", &[]);
        conversation.messages = vec![
            ChatMessage {
                role: "system".to_owned(),
                content: "be brief".to_owned(),
            },
            ChatMessage {
                role: "user".to_owned(),
                content: "ping".to_owned(),
            },
        ];
        let completion = complete_chat(
            Arc::new(MirrorEngine),
            fixture.catalog.clone(),
            "",
            conversation,
        )
        .await
        .expect("completion");

        assert_eq!(
            completion.choices[0].message.content,
            "system: be brief\nuser: ping"
        );
    }

    /// Was `stream_true_is_rejected`. D1 reverses that behaviour: every engine
    /// accepts stream: true, and the header says whether it was real.
    #[tokio::test]
    async fn streaming_emits_ordered_chunks_and_marks_emulation() {
        let fixture = fixture();
        let mut request = request("", &["Hello"]);
        request.stream = Some(true);

        let response = stream_chat(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            request,
        )
        .await
        .expect("the echo engine streams by emulation");

        assert_eq!(
            response
                .headers()
                .get("x-hologram-stream")
                .expect("the marker is always present")
                .to_str()
                .expect("ascii"),
            "emulated"
        );

        let body = collect_sse(response).await;
        let frames = sse_frames(&body);

        // `body.contains(...)` alone would pass even if the chunks were
        // emitted out of order; positions on the split frames are what
        // actually prove the sequence.
        let role_pos = frames
            .iter()
            .position(|frame| frame.contains("\"role\":\"assistant\""))
            .unwrap_or_else(|| panic!("the role chunk is present: {body}"));
        let content_pos = frames
            .iter()
            .position(|frame| frame.contains("\"content\":\"Hello\""))
            .unwrap_or_else(|| panic!("the content chunk is present: {body}"));
        let stop_pos = frames
            .iter()
            .position(|frame| frame.contains("\"finish_reason\":\"stop\""))
            .unwrap_or_else(|| panic!("the stop chunk is present: {body}"));
        let done_pos = frames.len() - 1;
        assert!(
            frames[done_pos].contains("[DONE]"),
            "the stream ends with [DONE]: {body}"
        );

        assert!(
            role_pos < content_pos,
            "role announces before content: {body}"
        );
        assert!(
            content_pos < stop_pos,
            "content precedes the stop chunk: {body}"
        );
        assert!(stop_pos < done_pos, "stop precedes [DONE]: {body}");
    }

    /// Reads a streaming response body to a String for assertion.
    async fn collect_sse(response: Response) -> String {
        let bytes = axum::body::to_bytes(response.into_body(), 64 * 1024)
            .await
            .expect("read the streamed body");
        String::from_utf8(bytes.to_vec()).expect("utf-8")
    }

    /// Splits a collected SSE body into its individual `data: ...` frames
    /// (events are blank-line delimited) in arrival order, for tests that
    /// need to assert ordering rather than mere presence.
    fn sse_frames(body: &str) -> Vec<&str> {
        body.split("\n\n")
            .filter(|frame| !frame.trim().is_empty())
            .collect()
    }

    #[tokio::test]
    async fn include_usage_adds_no_chunk_when_the_engine_measured_nothing() {
        let fixture = fixture();
        let mut request = request("", &["Hello"]);
        request.stream = Some(true);
        request.stream_options = Some(StreamOptions {
            include_usage: true,
        });

        let response = stream_chat(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            request,
        )
        .await
        .expect("the echo engine streams by emulation");

        let body = collect_sse(response).await;
        assert!(
            !body.contains("\"usage\""),
            "echo measures nothing, so no usage chunk is emitted (D3): {body}"
        );
    }

    /// Reports both token counts so the positive `include_usage` streaming
    /// path (the `if let Some(usage) = usage` branch) has coverage; without
    /// this, both streaming tests passed under an implementation that
    /// dropped the usage chunk unconditionally.
    struct MeteredEngine;

    #[tonic::async_trait]
    impl InferenceEngine for MeteredEngine {
        fn name(&self) -> &'static str {
            "metered"
        }

        async fn complete(&self, request: CompletionRequest) -> crate::error::Result<Completion> {
            Ok(Completion {
                text: request.prompt,
                model: "metered".to_owned(),
                tokens_per_second: None,
                elapsed_millis: 0,
                usage: Some(crate::inference::TokenUsage {
                    prompt_tokens: 11,
                    completion_tokens: 22,
                }),
            })
        }

        async fn list_models(&self) -> crate::error::Result<Vec<ModelInfo>> {
            Ok(Vec::new())
        }
    }

    #[tokio::test]
    async fn include_usage_adds_a_usage_chunk_before_done_when_the_engine_measured_counts() {
        let fixture = fixture();
        let mut request = request("", &["Hello"]);
        request.stream = Some(true);
        request.stream_options = Some(StreamOptions {
            include_usage: true,
        });

        let response = stream_chat(
            Arc::new(MeteredEngine),
            fixture.catalog.clone(),
            "",
            request,
        )
        .await
        .expect("the metered engine streams by emulation");

        let body = collect_sse(response).await;
        let frames = sse_frames(&body);

        let usage_pos = frames
            .iter()
            .position(|frame| frame.contains("\"usage\""))
            .unwrap_or_else(|| panic!("a usage chunk is emitted (D3): {body}"));
        let done_pos = frames.len() - 1;
        assert!(
            frames[done_pos].contains("[DONE]"),
            "the stream ends with [DONE]: {body}"
        );
        assert_eq!(
            usage_pos,
            done_pos - 1,
            "the usage chunk sits immediately before [DONE]: {body}"
        );

        let usage_frame = frames[usage_pos];
        assert!(
            usage_frame.contains("\"choices\":[]"),
            "the usage chunk carries empty choices: {usage_frame}"
        );
        assert!(
            usage_frame.contains("\"total_tokens\":33"),
            "11 prompt + 22 completion tokens: {usage_frame}"
        );
    }

    /// Proves both that a native engine's mid-stream failure is reported
    /// in-band (§4: the status is already 200, so this is the only honest
    /// way to report it) and that `x-hologram-stream` is genuinely derived
    /// from `stream_kind()` rather than hardcoded — every other fixture in
    /// this module is `Buffered`, so a hardcoded "emulated" would pass every
    /// other assertion in this file.
    #[tokio::test]
    async fn a_mid_stream_failure_is_reported_in_band_and_marked_native() {
        let fixture = fixture();
        let mut request = request("", &["Hello"]);
        request.stream = Some(true);

        let response = stream_chat(
            Arc::new(HalfwayFailingEngine),
            fixture.catalog.clone(),
            "",
            request,
        )
        .await
        .expect("the stream opens before the failure occurs");

        assert_eq!(
            response
                .headers()
                .get("x-hologram-stream")
                .expect("the marker is always present")
                .to_str()
                .expect("ascii"),
            "native"
        );

        let body = collect_sse(response).await;
        let frames = sse_frames(&body);

        // Positional, not just "somewhere in the body": the delta must
        // arrive before the error envelope, and [DONE] must be last.
        let delta_pos = frames
            .iter()
            .position(|frame| frame.contains(r#""content":"Hel""#))
            .unwrap_or_else(|| panic!("the delta arrives: {body}"));
        let error_pos = frames
            .iter()
            .position(|frame| frame.contains("LIVE_TRANSPORT_UNAVAILABLE"))
            .unwrap_or_else(|| panic!("the failure is reported in-band: {body}"));
        let done_pos = frames.len() - 1;
        assert!(
            frames[done_pos].contains("[DONE]"),
            "the stream ends with [DONE]: {body}"
        );
        assert!(
            delta_pos < error_pos,
            "the delta precedes the in-band error: {body}"
        );
        assert!(
            error_pos < done_pos,
            "the in-band error precedes [DONE]: {body}"
        );

        // Proves absence, not just that some other frame is present: a
        // failed stream must never claim a clean stop anywhere in the body,
        // and this would also catch a swallowed error that let the normal
        // stop/[DONE] tail run instead.
        assert!(
            !body.contains(r#""finish_reason":"stop""#),
            "a failed stream must not claim a clean stop: {body}"
        );
        assert!(body.trim_end().ends_with("data: [DONE]"), "{body}");
    }

    /// `stream_chat` rejects empty messages before touching the engine at
    /// all, same as the non-streaming path. Mirrors
    /// `ollama_compat::stream_chat_rejects_empty_messages`; before this test
    /// the `OpenAI` surface's pre-stream guard (`:361`) had no coverage at all.
    #[tokio::test]
    async fn stream_chat_rejects_empty_messages() {
        let fixture = fixture();
        let mut request = request("", &[]);
        request.stream = Some(true);

        let error = stream_chat(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            request,
        )
        .await
        .expect_err("must fail");

        assert_eq!(error.status, StatusCode::BAD_REQUEST);
        assert_eq!(error.body.kind, "invalid_request_error");
    }

    /// An unknown model must fail *before* a response is returned: a typed
    /// 404, not a stream that opens and then fails in-band. Mirrors
    /// `ollama_compat::stream_generate_rejects_an_unknown_model_before_returning_a_body`;
    /// before this test the `OpenAI` surface's pre-stream model resolution
    /// (`:364`) had no coverage at all.
    #[tokio::test]
    async fn stream_chat_rejects_an_unknown_model_before_returning_a_body() {
        let fixture = fixture();
        let mut request = request("ghost", &["hi"]);
        request.stream = Some(true);

        let error = stream_chat(Arc::new(MirrorEngine), fixture.catalog.clone(), "", request)
            .await
            .expect_err("must fail");

        assert_eq!(error.status, StatusCode::NOT_FOUND);
        assert_eq!(error.body.kind, "not_found_error");
    }

    #[tokio::test]
    async fn unknown_model_is_a_not_found_error() {
        let fixture = fixture();
        let error = complete_chat(
            Arc::new(MirrorEngine),
            fixture.catalog.clone(),
            "",
            request("ghost", &["hi"]),
        )
        .await
        .expect_err("must fail");

        assert_eq!(error.status, StatusCode::NOT_FOUND);
        assert_eq!(error.body.kind, "not_found_error");
    }

    #[tokio::test]
    async fn empty_model_falls_back_to_the_default_model() {
        let fixture = fixture();
        let imported = import_model(&fixture);
        let completion = complete_chat(
            Arc::new(MirrorEngine),
            fixture.catalog.clone(),
            &imported.id,
            request("", &["hi"]),
        )
        .await
        .expect("completion");

        assert_eq!(completion.model, "tiny");
    }

    #[tokio::test]
    async fn model_resolves_by_catalog_name() {
        let fixture = fixture();
        let imported = import_model(&fixture);
        let completion = complete_chat(
            Arc::new(MirrorEngine),
            fixture.catalog.clone(),
            "",
            request("tiny", &["hi"]),
        )
        .await
        .expect("completion");

        assert_eq!(completion.model, imported.name);
    }

    #[test]
    fn model_list_uses_the_openai_list_shape() {
        let fixture = fixture();
        let imported = import_model(&fixture);
        let list = model_list(fixture.catalog.list().expect("list"));

        assert_eq!(list.object, "list");
        assert_eq!(list.data.len(), 1);
        assert_eq!(list.data[0].id, imported.id);
        assert_eq!(list.data[0].object, "model");
        assert_eq!(list.data[0].owned_by, "hologram");
        assert_eq!(list.data[0].created, imported.created_at_millis / 1000);
    }

    #[test]
    fn error_envelope_serializes_in_the_openai_shape() {
        let response = OpenAiError::not_found("missing").into_response();
        assert_eq!(response.status(), StatusCode::NOT_FOUND);
        let envelope = OpenAiErrorEnvelope {
            error: OpenAiErrorBody {
                message: "missing".to_owned(),
                kind: "not_found_error".to_owned(),
                code: None,
            },
        };
        let json = serde_json::to_value(envelope).expect("serialize");
        assert_eq!(json["error"]["message"], "missing");
        assert_eq!(json["error"]["type"], "not_found_error");
        assert_eq!(json["error"]["code"], serde_json::Value::Null);
    }

    /// README.md and the `utoipa` annotation both promise `x-hologram-stream`
    /// "on both streaming and non-streaming responses"; before this test (and
    /// the corresponding fix) the header was only ever set on the SSE path.
    #[tokio::test]
    async fn non_streaming_chat_completion_carries_the_stream_header() {
        let fixture = fixture();
        let response = dispatch_chat_completions(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            request("", &["hi"]),
        )
        .await
        .expect("the echo engine always completes");

        assert_eq!(
            response
                .headers()
                .get("x-hologram-stream")
                .expect("the marker is present on non-streaming responses too")
                .to_str()
                .expect("ascii"),
            "emulated"
        );
    }

    /// Exercises the `stream == Some(true)` branch in `dispatch_chat_completions`
    /// directly (the code the public `chat_completions` handler reduces to
    /// after `AppState` extraction), since no test otherwise touches the
    /// handler itself: deleting the branch would silently revert the
    /// endpoint to buffered-only while every other test stayed green.
    #[tokio::test]
    async fn dispatch_chat_completions_streams_or_not_based_on_the_request() {
        let fixture = fixture();

        let mut streaming = request("", &["hi"]);
        streaming.stream = Some(true);
        let streaming_response = dispatch_chat_completions(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            streaming,
        )
        .await
        .expect("the echo engine streams by emulation");
        assert_eq!(
            streaming_response
                .headers()
                .get(axum::http::header::CONTENT_TYPE)
                .expect("content type is set")
                .to_str()
                .expect("ascii"),
            "text/event-stream"
        );

        let mut buffered = request("", &["hi"]);
        buffered.stream = None;
        let buffered_response = dispatch_chat_completions(
            Arc::new(crate::inference::EchoEngine),
            fixture.catalog.clone(),
            "echo",
            buffered,
        )
        .await
        .expect("the echo engine always completes");
        assert_eq!(
            buffered_response
                .headers()
                .get(axum::http::header::CONTENT_TYPE)
                .expect("content type is set")
                .to_str()
                .expect("ascii"),
            "application/json"
        );
    }
}
