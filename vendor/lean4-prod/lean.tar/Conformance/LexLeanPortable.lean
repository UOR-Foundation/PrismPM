module
public import Init
set_option autoImplicit false
namespace SemanticFixture.Portable

namespace LexLeanRuntime

public class ToMathInt (α : Type) where
  toInt : α -> Int

public class Fixed (α : Type) extends ToMathInt α where
  fromInt : Int -> α
  minimum : Int
  maximum : Int
  bitAnd : α -> α -> α
  bitOr : α -> α -> α
  bitXor : α -> α -> α
  bitNot : α -> α
  shiftLeft : α -> UInt32 -> Option α
  shiftRight : α -> UInt32 -> Option α

public instance : ToMathInt Int where toInt := fun value => value

public instance : Fixed Int8 where
  toInt := Int8.toInt
  fromInt := Int8.ofInt
  minimum := -128
  maximum := 127
  bitAnd := Int8.land
  bitOr := Int8.lor
  bitXor := Int8.xor
  bitNot := Int8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (Int8.shiftLeft value (Int8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (Int8.shiftRight value (Int8.ofNat amount.toNat)) else none

public instance : Fixed Int16 where
  toInt := Int16.toInt
  fromInt := Int16.ofInt
  minimum := -32768
  maximum := 32767
  bitAnd := Int16.land
  bitOr := Int16.lor
  bitXor := Int16.xor
  bitNot := Int16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (Int16.shiftLeft value (Int16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (Int16.shiftRight value (Int16.ofNat amount.toNat)) else none

public instance : Fixed Int32 where
  toInt := Int32.toInt
  fromInt := Int32.ofInt
  minimum := -2147483648
  maximum := 2147483647
  bitAnd := Int32.land
  bitOr := Int32.lor
  bitXor := Int32.xor
  bitNot := Int32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (Int32.shiftLeft value (Int32.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (Int32.shiftRight value (Int32.ofNat amount.toNat)) else none

public instance : Fixed Int64 where
  toInt := Int64.toInt
  fromInt := Int64.ofInt
  minimum := -9223372036854775808
  maximum := 9223372036854775807
  bitAnd := Int64.land
  bitOr := Int64.lor
  bitXor := Int64.xor
  bitNot := Int64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (Int64.shiftLeft value (Int64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (Int64.shiftRight value (Int64.ofNat amount.toNat)) else none

public instance : Fixed UInt8 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt8.ofInt
  minimum := 0
  maximum := 255
  bitAnd := UInt8.land
  bitOr := UInt8.lor
  bitXor := UInt8.xor
  bitNot := UInt8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (UInt8.shiftLeft value (UInt8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (UInt8.shiftRight value (UInt8.ofNat amount.toNat)) else none

public instance : Fixed UInt16 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt16.ofInt
  minimum := 0
  maximum := 65535
  bitAnd := UInt16.land
  bitOr := UInt16.lor
  bitXor := UInt16.xor
  bitNot := UInt16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (UInt16.shiftLeft value (UInt16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (UInt16.shiftRight value (UInt16.ofNat amount.toNat)) else none

public instance : Fixed UInt32 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt32.ofInt
  minimum := 0
  maximum := 4294967295
  bitAnd := UInt32.land
  bitOr := UInt32.lor
  bitXor := UInt32.xor
  bitNot := UInt32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (UInt32.shiftLeft value amount) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (UInt32.shiftRight value amount) else none

public instance : Fixed UInt64 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt64.ofInt
  minimum := 0
  maximum := 18446744073709551615
  bitAnd := UInt64.land
  bitOr := UInt64.lor
  bitXor := UInt64.xor
  bitNot := UInt64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (UInt64.shiftLeft value (UInt64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (UInt64.shiftRight value (UInt64.ofNat amount.toNat)) else none

@[expose] public def checkedFromInt {α : Type} [Fixed α] (value : Int) : Option α :=
  if value < Fixed.minimum (α := α) then none else if Fixed.maximum (α := α) < value then none else some (Fixed.fromInt value)

@[expose] public def checkedConvert {α β : Type} [ToMathInt α] [Fixed β] (value : α) : Option β :=
  checkedFromInt (ToMathInt.toInt value)

@[expose] public def checkedAdd {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left + ToMathInt.toInt right)

@[expose] public def checkedSubtract {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left - ToMathInt.toInt right)

@[expose] public def checkedMultiply {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left * ToMathInt.toInt right)

@[expose] public def checkedNegate {α : Type} [Fixed α] (value : α) : Option α :=
  checkedFromInt (-ToMathInt.toInt value)

@[expose] public def checkedQuotient {α : Type} [Fixed α] (left right : α) : Option α :=
  if ToMathInt.toInt right = 0 then none else checkedFromInt (Int.tdiv (ToMathInt.toInt left) (ToMathInt.toInt right))

@[expose] public def checkedAddInt64 (left right : Int64) : Option Int64 :=
  let value := left + right
  if (0 < right && value < left) || (right < 0 && left < value) then none else some value

@[expose] public def checkedSubtractInt64 (left right : Int64) : Option Int64 :=
  let value := left - right
  if (0 < right && left < value) || (right < 0 && value < left) then none else some value

@[expose] public def checkedNegateInt64 (value : Int64) : Option Int64 :=
  if value == (-9223372036854775808 : Int64) then none else some (-value)

public def magnitudeInt64 (value : Int64) : UInt64 :=
  let bits := value.toUInt64
  if value < 0 then 0 - bits else bits

public def signedMagnitudeInt64 (negative : Bool) (value : UInt64) : Int64 :=
  (if negative then 0 - value else value).toInt64

public def divideMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> UInt64 -> UInt64
  | 0, _, _, _, quotient => quotient
  | Nat.succ fuel, source, divisor, remainder, quotient =>
      let high := 9223372036854775808 <= source
      let source := source + source
      let remainder := remainder + remainder + if high then 1 else 0
      let quotient := quotient + quotient
      if divisor <= remainder then
        divideMagnitudeInt64 fuel source divisor (remainder - divisor) (quotient + 1)
      else
        divideMagnitudeInt64 fuel source divisor remainder quotient

@[expose] public def checkedQuotientInt64 (left right : Int64) : Option Int64 :=
  if right == 0 then none
  else if left == (-9223372036854775808 : Int64) && right == (-1 : Int64) then none
  else
    let negative := (left < 0) != (right < 0)
    some (signedMagnitudeInt64 negative
      (divideMagnitudeInt64 64 (magnitudeInt64 left) (magnitudeInt64 right) 0 0))

public def multiplyMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> Bool -> Option UInt64
  | 0, _, _, accumulator, _ => some accumulator
  | Nat.succ fuel, source, multiplicand, accumulator, negative =>
      let high := 9223372036854775808 <= source
      let limit := if negative then 9223372036854775808 else 9223372036854775807
      let halfLimit := if negative then 4611686018427387904 else 4611686018427387903
      if halfLimit < accumulator then none
      else
        let doubled := accumulator + accumulator
        if high then
          if limit < multiplicand || limit - multiplicand < doubled then none
          else multiplyMagnitudeInt64 fuel (source + source) multiplicand
            (doubled + multiplicand) negative
        else
          multiplyMagnitudeInt64 fuel (source + source) multiplicand doubled negative

@[expose] public def checkedMultiplyInt64 (left right : Int64) : Option Int64 :=
  let negative := (left < 0) != (right < 0)
  match multiplyMagnitudeInt64 64 (magnitudeInt64 right) (magnitudeInt64 left) 0 negative with
  | none => none
  | some value => some (signedMagnitudeInt64 negative value)

@[noinline] public def subtract {α : Type} [Sub α] (left right : α) : α := left - right
@[noinline] public def multiply {α : Type} [Mul α] (left right : α) : α := left * right
@[noinline] public def negate {α : Type} [Neg α] (value : α) : α := -value

public class Quotient (α : Type) where
  quotient : α -> α -> α
  remainder : α -> α -> α
  isZero : α -> Bool

public instance : Quotient Nat where
  quotient := Nat.div
  remainder := Nat.mod
  isZero := fun value => value == 0

public instance : Quotient Int where
  quotient := Int.tdiv
  remainder := Int.tmod
  isZero := fun value => value == 0

@[noinline] public def quotient {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.quotient left right

@[noinline] public def remainder {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.remainder left right

@[expose] public def bitAnd {α : Type} [Fixed α] (left right : α) : α := Fixed.bitAnd left right
@[expose] public def bitOr {α : Type} [Fixed α] (left right : α) : α := Fixed.bitOr left right
@[expose] public def bitXor {α : Type} [Fixed α] (left right : α) : α := Fixed.bitXor left right
@[expose] public def bitNot {α : Type} [Fixed α] (value : α) : α := Fixed.bitNot value
@[expose] public def shiftLeft {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftLeft value amount
@[expose] public def shiftRight {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftRight value amount

public class Appendable (α : Type) where append : α -> α -> α
public instance {α : Type} : Appendable (List α) where append := List.append
public instance : Appendable ByteArray where append := ByteArray.append
@[noinline] public def append {α : Type} [Appendable α] (left right : α) : α := Appendable.append left right

public class Lengthable (α : Type) where length : α -> Nat
public instance {α : Type} : Lengthable (List α) where length := List.length
public instance : Lengthable ByteArray where length := ByteArray.size
public instance : Lengthable String where length := String.length
@[noinline] public def length {α : Type} [Lengthable α] (value : α) : Nat := Lengthable.length value

@[expose] public def listIndex {α : Type} : List α -> Nat -> Option α
  | [], _ => none
  | head :: _, 0 => some head
  | _ :: tail, index + 1 => listIndex tail index

public class Indexable (α β : Type) where index : α -> Nat -> Option β
public instance {α : Type} : Indexable (List α) α where index := listIndex
public instance : Indexable ByteArray UInt8 where index := fun value offset => value.data[offset]?
@[noinline] public def index {α β : Type} [Indexable α β] (value : α) (offset : Nat) : Option β := Indexable.index value offset

public class Sliceable (α : Type) where slice : α -> Nat -> Nat -> Option α
public instance {α : Type} : Sliceable (List α) where
  slice := fun value start count => if start + count <= value.length then some ((value.drop start).take count) else none
public instance : Sliceable ByteArray where
  slice := fun value start count => if start + count <= value.size then some (value.extract start (start + count)) else none
@[noinline] public def slice {α : Type} [Sliceable α] (value : α) (start count : Nat) : Option α := Sliceable.slice value start count

@[noinline] public def utf8Encode (value : String) : ByteArray := value.toUTF8
@[noinline] public def utf8Decode (value : ByteArray) : Option String := String.fromUTF8? value
@[noinline] public def compareBytes (left right : ByteArray) : Ordering := compare left.toList right.toList
@[expose] public def equal {α : Type} [BEq α] (left right : α) : Bool := left == right

@[noinline] public def splitExact (value delimiter : String) (maximum : UInt32) : Option (List String) :=
  let fields := value.splitOn delimiter
  if delimiter.isEmpty || maximum.toNat < fields.length then none else some fields

@[noinline] public def join (values : List String) (delimiter : String) : String := delimiter.intercalate values

public class Decimal (α : Type) where
  parse : String -> Option α
  format : α -> String

public instance : Decimal Int where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then some parsed else none | none => none
  format := toString

public instance {α : Type} [Fixed α] [ToString α] : Decimal α where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then checkedFromInt parsed else none | none => none
  format := toString

@[noinline] public def parseDecimal {α : Type} [Decimal α] (value : String) : Option α := Decimal.parse value
@[noinline] public def formatDecimal {α : Type} [Decimal α] (value : α) : String := Decimal.format value

-- Runtime namespace membership never authorizes an unknown semantic callable.
@[noinline] public def fakeNatHelper (value : Nat) : Nat := value + 1

-- The exact append recognizer must reject altered operands and additional work.
@[noinline] public def alteredByteCopy (left right : ByteArray) : ByteArray :=
  ByteArray.copySlice right 0 left right.size left.size false

@[noinline] public def extraByteCopy (left right : ByteArray) : ByteArray :=
  ByteArray.copySlice right 0 left (left.size + 1) right.size false

end LexLeanRuntime

public structure PortableContainers where
  optional : Option (Int64)
  fallible : Except (String) (Int64)

@[expose] public def minimumInt8 : Int8 := (-128 : Int8)

@[expose] public def minimumInt16 : Int16 := (-32768 : Int16)

@[expose] public def minimumInt32 : Int32 := (-2147483648 : Int32)

@[expose] public def minimumInt64 : Int64 := (-9223372036854775808 : Int64)

@[expose] public def maximumUInt8 : UInt8 := (255 : UInt8)

@[expose] public def maximumUInt16 : UInt16 := (65535 : UInt16)

@[expose] public def maximumUInt32 : UInt32 := (4294967295 : UInt32)

@[expose] public def maximumUInt64 : UInt64 := (18446744073709551615 : UInt64)

@[expose] public def unboundedInteger : Int := (-123456789012345678901234567890 : Int)

@[expose] public def isZeroInt64 (value : Int64) : Bool := (LexLeanRuntime.equal (value) ((0 : Int64)) : Bool)

@[expose] public def checkedAddInt64 (left : Int64) (right : Int64) : Option (Int64) := (LexLeanRuntime.checkedAddInt64 (left) (right) : Option (Int64))

@[expose] public def checkedQuotientInt64 (left : Int64) (right : Int64) : Option (Int64) := (LexLeanRuntime.checkedQuotientInt64 (left) (right) : Option (Int64))

@[expose] public def parseInt64 (value : String) : Option (Int64) := (LexLeanRuntime.parseDecimal (value) : Option (Int64))

@[expose] public def formatInt64 (value : Int64) : String := (LexLeanRuntime.formatDecimal (value) : String)

@[expose] public def byteFixture : ByteArray := ByteArray.mk #[170, 187, 127, 255]

-- Closed literal boundaries exercised by the actual portable-package gate.
@[expose] public def emptyByteFixture : ByteArray := ByteArray.mk #[]

@[expose] public def byteLiteralEquals (value : ByteArray) : Bool :=
  LexLeanRuntime.equal value (ByteArray.mk #[0, 128, 255])

@[expose] public def emptyByteLiteralEquals : Bool :=
  LexLeanRuntime.equal (ByteArray.mk #[]) (ByteArray.mk #[])

@[expose] public def nestedByteFixture (choose : Bool) (value : ByteArray) : ByteArray :=
  if choose then LexLeanRuntime.append (ByteArray.mk #[0, 128, 255]) value
  else ByteArray.mk #[255, 0]

@[expose] public def reuseByteFixture (value : ByteArray) : ByteArray :=
  match LexLeanRuntime.utf8Decode value with
  | none => ByteArray.mk #[255, 0]
  | some _ => LexLeanRuntime.append (ByteArray.mk #[0, 128, 255]) value

-- Literal support must not silently widen the supported Array subset.
@[expose] public def unsupportedArrayFixture : Array UInt8 := #[0, 255]

@[expose] public def unsupportedDynamicByteFixture (value : UInt8) : ByteArray :=
  ByteArray.mk #[value]

@[expose] public def encodeUtf8 (value : String) : ByteArray := (LexLeanRuntime.utf8Encode (value) : ByteArray)

@[expose] public def decodeUtf8 (value : ByteArray) : Option (String) := (LexLeanRuntime.utf8Decode (value) : Option (String))

@[expose] public def shiftUInt64 (value : UInt64) (amount : UInt32) : Option (UInt64) := (LexLeanRuntime.shiftLeft (value) (amount) : Option (UInt64))

@[expose] public def subtractInt (left : Int) (right : Int) : Int := (LexLeanRuntime.subtract (left) (right) : Int)

@[expose] public def multiplyInt (left : Int) (right : Int) : Int := (LexLeanRuntime.multiply (left) (right) : Int)

@[expose] public def quotientInt (left : Int) (right : Int) (zeroCase : Int) : Int := (LexLeanRuntime.quotient (left) (right) (zeroCase) : Int)

@[expose] public def remainderInt (left : Int) (right : Int) (zeroCase : Int) : Int := (LexLeanRuntime.remainder (left) (right) (zeroCase) : Int)

@[expose] public def negateInt (value : Int) : Int := (LexLeanRuntime.negate (value) : Int)

@[expose] public def convertInt64 (value : Int) : Option (Int64) := (LexLeanRuntime.checkedConvert (value) : Option (Int64))

@[expose] public def checkedSubtractInt64 (left : Int64) (right : Int64) : Option (Int64) := (LexLeanRuntime.checkedSubtractInt64 (left) (right) : Option (Int64))

@[expose] public def checkedMultiplyInt64 (left : Int64) (right : Int64) : Option (Int64) := (LexLeanRuntime.checkedMultiplyInt64 (left) (right) : Option (Int64))

@[expose] public def checkedNegateInt64 (value : Int64) : Option (Int64) := (LexLeanRuntime.checkedNegateInt64 (value) : Option (Int64))

@[expose] public def andUInt64 (left : UInt64) (right : UInt64) : UInt64 := (LexLeanRuntime.bitAnd (left) (right) : UInt64)

@[expose] public def orUInt64 (left : UInt64) (right : UInt64) : UInt64 := (LexLeanRuntime.bitOr (left) (right) : UInt64)

@[expose] public def xorUInt64 (left : UInt64) (right : UInt64) : UInt64 := (LexLeanRuntime.bitXor (left) (right) : UInt64)

@[expose] public def notUInt64 (value : UInt64) : UInt64 := (LexLeanRuntime.bitNot (value) : UInt64)

@[expose] public def shiftRightUInt64 (value : UInt64) (amount : UInt32) : Option (UInt64) := (LexLeanRuntime.shiftRight (value) (amount) : Option (UInt64))

@[expose] public def appendBytes (left : ByteArray) (right : ByteArray) : ByteArray := (LexLeanRuntime.append (left) (right) : ByteArray)

@[expose] public def byteLength (value : ByteArray) : Nat := (LexLeanRuntime.length (value) : Nat)

@[expose] public def byteAt (value : ByteArray) (offset : Nat) : Option (UInt8) := (LexLeanRuntime.index (value) (offset) : Option (UInt8))

@[expose] public def sliceBytes (value : ByteArray) (start : Nat) (count : Nat) : Option (ByteArray) := (LexLeanRuntime.slice (value) (start) (count) : Option (ByteArray))

@[expose] public def compareByteStrings (left : ByteArray) (right : ByteArray) : Ordering := (LexLeanRuntime.compareBytes (left) (right) : Ordering)

-- Lean may simplify composition of the stdlib wrappers to ByteArray.size.
@[expose] public def wrappedByteLength (value : ByteArray) : Nat := byteLength value

@[expose] public def wrappedAppendBytes (left right : ByteArray) : ByteArray :=
  appendBytes left right

@[expose] public def aliasedAppendBytes (value : ByteArray) : ByteArray :=
  appendBytes value value

@[expose] public def unsupportedRuntimeNatFixture (value : Nat) : Nat :=
  LexLeanRuntime.fakeNatHelper value

@[expose] public def unsupportedAlteredByteCopy (left right : ByteArray) : ByteArray :=
  LexLeanRuntime.alteredByteCopy left right

@[expose] public def unsupportedExtraByteCopy (left right : ByteArray) : ByteArray :=
  LexLeanRuntime.extraByteCopy left right

@[expose] public def boundedReuseByteFixture (value : ByteArray) : ByteArray :=
  if byteLength value == 0 then ByteArray.mk #[255, 0]
  else if 64 < byteLength value then ByteArray.mk #[255, 0]
  else match decodeUtf8 value with
    | none => ByteArray.mk #[255, 0]
    | some _ => appendBytes (ByteArray.mk #[0, 128, 255]) value

@[expose] public def splitBounded (value : String) (delimiter : String) (maximum : UInt32) : Option (List (String)) := (LexLeanRuntime.splitExact (value) (delimiter) (maximum) : Option (List (String)))

@[expose] public def joinStrings (values : List (String)) (delimiter : String) : String := (LexLeanRuntime.join (values) (delimiter) : String)

@[expose] public def unicodeFixture : String := "portable ✓"

end SemanticFixture.Portable
