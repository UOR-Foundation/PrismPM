module
public import Init
set_option autoImplicit false
namespace PrismCalculator.Calculator

namespace LexLeanRuntime

public class ToMathInt (α : Type) where
  toInt : α -> Int

public class Fixed (α : Type) extends ToMathInt α where
  fromInt : Int -> α
  minimum : Int
  maximum : Int
  bitAnd : α -> α -> α
  bitOr : α -> α -> α
  bitXor : α -> α -> α
  bitNot : α -> α
  shiftLeft : α -> UInt32 -> Option α
  shiftRight : α -> UInt32 -> Option α

public instance : ToMathInt Int where toInt := fun value => value

public instance : Fixed Int8 where
  toInt := Int8.toInt
  fromInt := Int8.ofInt
  minimum := -128
  maximum := 127
  bitAnd := Int8.land
  bitOr := Int8.lor
  bitXor := Int8.xor
  bitNot := Int8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (Int8.shiftLeft value (Int8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (Int8.shiftRight value (Int8.ofNat amount.toNat)) else none

public instance : Fixed Int16 where
  toInt := Int16.toInt
  fromInt := Int16.ofInt
  minimum := -32768
  maximum := 32767
  bitAnd := Int16.land
  bitOr := Int16.lor
  bitXor := Int16.xor
  bitNot := Int16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (Int16.shiftLeft value (Int16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (Int16.shiftRight value (Int16.ofNat amount.toNat)) else none

public instance : Fixed Int32 where
  toInt := Int32.toInt
  fromInt := Int32.ofInt
  minimum := -2147483648
  maximum := 2147483647
  bitAnd := Int32.land
  bitOr := Int32.lor
  bitXor := Int32.xor
  bitNot := Int32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (Int32.shiftLeft value (Int32.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (Int32.shiftRight value (Int32.ofNat amount.toNat)) else none

public instance : Fixed Int64 where
  toInt := Int64.toInt
  fromInt := Int64.ofInt
  minimum := -9223372036854775808
  maximum := 9223372036854775807
  bitAnd := Int64.land
  bitOr := Int64.lor
  bitXor := Int64.xor
  bitNot := Int64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (Int64.shiftLeft value (Int64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (Int64.shiftRight value (Int64.ofNat amount.toNat)) else none

public instance : Fixed UInt8 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt8.ofInt
  minimum := 0
  maximum := 255
  bitAnd := UInt8.land
  bitOr := UInt8.lor
  bitXor := UInt8.xor
  bitNot := UInt8.complement
  shiftLeft := fun value amount => if amount.toNat < 8 then some (UInt8.shiftLeft value (UInt8.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 8 then some (UInt8.shiftRight value (UInt8.ofNat amount.toNat)) else none

public instance : Fixed UInt16 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt16.ofInt
  minimum := 0
  maximum := 65535
  bitAnd := UInt16.land
  bitOr := UInt16.lor
  bitXor := UInt16.xor
  bitNot := UInt16.complement
  shiftLeft := fun value amount => if amount.toNat < 16 then some (UInt16.shiftLeft value (UInt16.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 16 then some (UInt16.shiftRight value (UInt16.ofNat amount.toNat)) else none

public instance : Fixed UInt32 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt32.ofInt
  minimum := 0
  maximum := 4294967295
  bitAnd := UInt32.land
  bitOr := UInt32.lor
  bitXor := UInt32.xor
  bitNot := UInt32.complement
  shiftLeft := fun value amount => if amount.toNat < 32 then some (UInt32.shiftLeft value amount) else none
  shiftRight := fun value amount => if amount.toNat < 32 then some (UInt32.shiftRight value amount) else none

public instance : Fixed UInt64 where
  toInt := fun value => Int.ofNat value.toNat
  fromInt := UInt64.ofInt
  minimum := 0
  maximum := 18446744073709551615
  bitAnd := UInt64.land
  bitOr := UInt64.lor
  bitXor := UInt64.xor
  bitNot := UInt64.complement
  shiftLeft := fun value amount => if amount.toNat < 64 then some (UInt64.shiftLeft value (UInt64.ofNat amount.toNat)) else none
  shiftRight := fun value amount => if amount.toNat < 64 then some (UInt64.shiftRight value (UInt64.ofNat amount.toNat)) else none

@[expose] public def checkedFromInt {α : Type} [Fixed α] (value : Int) : Option α :=
  if value < Fixed.minimum (α := α) then none else if Fixed.maximum (α := α) < value then none else some (Fixed.fromInt value)

@[expose] public def checkedConvert {α β : Type} [ToMathInt α] [Fixed β] (value : α) : Option β :=
  checkedFromInt (ToMathInt.toInt value)

@[expose] public def checkedAdd {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left + ToMathInt.toInt right)

@[expose] public def checkedSubtract {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left - ToMathInt.toInt right)

@[expose] public def checkedMultiply {α : Type} [Fixed α] (left right : α) : Option α :=
  checkedFromInt (ToMathInt.toInt left * ToMathInt.toInt right)

@[expose] public def checkedNegate {α : Type} [Fixed α] (value : α) : Option α :=
  checkedFromInt (-ToMathInt.toInt value)

@[expose] public def checkedQuotient {α : Type} [Fixed α] (left right : α) : Option α :=
  if ToMathInt.toInt right = 0 then none else checkedFromInt (Int.tdiv (ToMathInt.toInt left) (ToMathInt.toInt right))

@[expose] public def checkedAddInt64 (left right : Int64) : Option Int64 :=
  let value := left + right
  if (0 < right && value < left) || (right < 0 && left < value) then none else some value

@[expose] public def checkedSubtractInt64 (left right : Int64) : Option Int64 :=
  let value := left - right
  if (0 < right && left < value) || (right < 0 && value < left) then none else some value

@[expose] public def checkedNegateInt64 (value : Int64) : Option Int64 :=
  if value == (-9223372036854775808 : Int64) then none else some (-value)

public def magnitudeInt64 (value : Int64) : UInt64 :=
  let bits := value.toUInt64
  if value < 0 then 0 - bits else bits

public def signedMagnitudeInt64 (negative : Bool) (value : UInt64) : Int64 :=
  (if negative then 0 - value else value).toInt64

public def divideMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> UInt64 -> UInt64
  | 0, _, _, _, quotient => quotient
  | Nat.succ fuel, source, divisor, remainder, quotient =>
      let high := 9223372036854775808 <= source
      let source := source + source
      let remainder := remainder + remainder + if high then 1 else 0
      let quotient := quotient + quotient
      if divisor <= remainder then
        divideMagnitudeInt64 fuel source divisor (remainder - divisor) (quotient + 1)
      else
        divideMagnitudeInt64 fuel source divisor remainder quotient

@[expose] public def checkedQuotientInt64 (left right : Int64) : Option Int64 :=
  if right == 0 then none
  else if left == (-9223372036854775808 : Int64) && right == (-1 : Int64) then none
  else
    let negative := (left < 0) != (right < 0)
    some (signedMagnitudeInt64 negative
      (divideMagnitudeInt64 64 (magnitudeInt64 left) (magnitudeInt64 right) 0 0))

public def multiplyMagnitudeInt64 : Nat -> UInt64 -> UInt64 -> UInt64 -> Bool -> Option UInt64
  | 0, _, _, accumulator, _ => some accumulator
  | Nat.succ fuel, source, multiplicand, accumulator, negative =>
      let high := 9223372036854775808 <= source
      let limit := if negative then 9223372036854775808 else 9223372036854775807
      let halfLimit := if negative then 4611686018427387904 else 4611686018427387903
      if halfLimit < accumulator then none
      else
        let doubled := accumulator + accumulator
        if high then
          if limit < multiplicand || limit - multiplicand < doubled then none
          else multiplyMagnitudeInt64 fuel (source + source) multiplicand
            (doubled + multiplicand) negative
        else
          multiplyMagnitudeInt64 fuel (source + source) multiplicand doubled negative

@[expose] public def checkedMultiplyInt64 (left right : Int64) : Option Int64 :=
  let negative := (left < 0) != (right < 0)
  match multiplyMagnitudeInt64 64 (magnitudeInt64 right) (magnitudeInt64 left) 0 negative with
  | none => none
  | some value => some (signedMagnitudeInt64 negative value)

@[noinline] public def subtract {α : Type} [Sub α] (left right : α) : α := left - right
@[noinline] public def multiply {α : Type} [Mul α] (left right : α) : α := left * right
@[noinline] public def negate {α : Type} [Neg α] (value : α) : α := -value

public class Quotient (α : Type) where
  quotient : α -> α -> α
  remainder : α -> α -> α
  isZero : α -> Bool

public instance : Quotient Nat where
  quotient := Nat.div
  remainder := Nat.mod
  isZero := fun value => value == 0

public instance : Quotient Int where
  quotient := Int.tdiv
  remainder := Int.tmod
  isZero := fun value => value == 0

@[noinline] public def quotient {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.quotient left right

@[noinline] public def remainder {α : Type} [Quotient α] (left right zeroCase : α) : α :=
  if Quotient.isZero right then zeroCase else Quotient.remainder left right

@[expose] public def bitAnd {α : Type} [Fixed α] (left right : α) : α := Fixed.bitAnd left right
@[expose] public def bitOr {α : Type} [Fixed α] (left right : α) : α := Fixed.bitOr left right
@[expose] public def bitXor {α : Type} [Fixed α] (left right : α) : α := Fixed.bitXor left right
@[expose] public def bitNot {α : Type} [Fixed α] (value : α) : α := Fixed.bitNot value
@[expose] public def shiftLeft {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftLeft value amount
@[expose] public def shiftRight {α : Type} [Fixed α] (value : α) (amount : UInt32) : Option α := Fixed.shiftRight value amount

public class Appendable (α : Type) where append : α -> α -> α
public instance {α : Type} : Appendable (List α) where append := List.append
public instance : Appendable ByteArray where append := ByteArray.append
@[noinline] public def append {α : Type} [Appendable α] (left right : α) : α := Appendable.append left right

public class Lengthable (α : Type) where length : α -> Nat
public instance {α : Type} : Lengthable (List α) where length := List.length
public instance : Lengthable ByteArray where length := ByteArray.size
public instance : Lengthable String where length := String.length
@[noinline] public def length {α : Type} [Lengthable α] (value : α) : Nat := Lengthable.length value

@[expose] public def listIndex {α : Type} : List α -> Nat -> Option α
  | [], _ => none
  | head :: _, 0 => some head
  | _ :: tail, index + 1 => listIndex tail index

public class Indexable (α β : Type) where index : α -> Nat -> Option β
public instance {α : Type} : Indexable (List α) α where index := listIndex
public instance : Indexable ByteArray UInt8 where index := fun value offset => value.data[offset]?
@[noinline] public def index {α β : Type} [Indexable α β] (value : α) (offset : Nat) : Option β := Indexable.index value offset

public class Sliceable (α : Type) where slice : α -> Nat -> Nat -> Option α
public instance {α : Type} : Sliceable (List α) where
  slice := fun value start count => if start + count <= value.length then some ((value.drop start).take count) else none
public instance : Sliceable ByteArray where
  slice := fun value start count => if start + count <= value.size then some (value.extract start (start + count)) else none
@[noinline] public def slice {α : Type} [Sliceable α] (value : α) (start count : Nat) : Option α := Sliceable.slice value start count

@[noinline] public def utf8Encode (value : String) : ByteArray := value.toUTF8
@[noinline] public def utf8Decode (value : ByteArray) : Option String := String.fromUTF8? value
@[noinline] public def compareBytes (left right : ByteArray) : Ordering := compare left.toList right.toList
@[expose] public def equal {α : Type} [BEq α] (left right : α) : Bool := left == right

@[noinline] public def splitExact (value delimiter : String) (maximum : UInt32) : Option (List String) :=
  let fields := value.splitOn delimiter
  if delimiter.isEmpty || maximum.toNat < fields.length then none else some fields

@[noinline] public def join (values : List String) (delimiter : String) : String := delimiter.intercalate values

public class Decimal (α : Type) where
  parse : String -> Option α
  format : α -> String

public instance : Decimal Int where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then some parsed else none | none => none
  format := toString

public instance {α : Type} [Fixed α] [ToString α] : Decimal α where
  parse := fun value => match value.toInt? with | some parsed => if toString parsed = value then checkedFromInt parsed else none | none => none
  format := toString

@[noinline] public def parseDecimal {α : Type} [Decimal α] (value : String) : Option α := Decimal.parse value
@[noinline] public def formatDecimal {α : Type} [Decimal α] (value : α) : String := Decimal.format value

end LexLeanRuntime

public inductive Operation where
  | Add
  | Subtract
  | Multiply
  | Divide

public inductive CalculatorError where
  | DivisionByZero
  | Overflow

public inductive ProtocolError where
  | MalformedRequest
  | UnsupportedVersion
  | UnknownOperation

public structure CalculatorView where
  title : String
  heading : String
  leftLabel : String
  rightLabel : String
  operationLabel : String
  submitLabel : String
  inputError : String
  divisionError : String
  overflowError : String
  livePolite : Bool
  retainFocus : Bool
  submitOnEnter : Bool
  hologramIntent : Bool
  pagesAdapter : Bool

public structure Request where
  operation : Operation
  left : Int64
  right : Int64

public inductive InputGrammar where
  | AsciiSignedI64

public inductive ViewAction where
  | Submit
  | Enter

public inductive LiveMode where
  | Polite

public inductive StyleToken where
  | Compact
  | HighContrast
  | SystemSans

public inductive PresentationTarget where
  | HologramPortable
  | GithubPages

public structure CalculatorApplication where
  name : String
  cargoName : String
  cargoVersion : String
  entryRoot : String
  coreContract : String
  requestMaximum : UInt32
  responseMaximum : UInt32
  guestAllocationMaximum : UInt32
  capabilitiesEmpty : Bool
  fatArchive : Bool
  primaryLayer : UInt8
  viewLayer : UInt8
  view : CalculatorView
  inputGrammar : InputGrammar
  liveMode : LiveMode
  layout : StyleToken
  color : StyleToken
  typography : StyleToken
  actions : List (ViewAction)
  targets : List (PresentationTarget)

@[expose] public def calculate (operation : Operation) (left : Int64) (right : Int64) : Except (CalculatorError) (Int64) := (match operation with | Operation.Add => (match (LexLeanRuntime.checkedAddInt64 (left) (right) : Option (Int64)) with | Option.none => Except.error (CalculatorError.Overflow) | Option.some value => Except.ok (value)) | Operation.Subtract => (match (LexLeanRuntime.checkedSubtractInt64 (left) (right) : Option (Int64)) with | Option.none => Except.error (CalculatorError.Overflow) | Option.some value => Except.ok (value)) | Operation.Multiply => (match (LexLeanRuntime.checkedMultiplyInt64 (left) (right) : Option (Int64)) with | Option.none => Except.error (CalculatorError.Overflow) | Option.some value => Except.ok (value)) | Operation.Divide => (if (LexLeanRuntime.equal (right) ((0 : Int64)) : Bool) then Except.error (CalculatorError.DivisionByZero) else (match (LexLeanRuntime.checkedQuotientInt64 (left) (right) : Option (Int64)) with | Option.none => Except.error (CalculatorError.Overflow) | Option.some value => Except.ok (value))))

@[expose] public def calculatorView : CalculatorView := ({ title := "Calculator", heading := "Calculator", leftLabel := "Left operand", rightLabel := "Right operand", operationLabel := "Operation", submitLabel := "Calculate", inputError := "Enter a signed 64-bit integer.", divisionError := "Division by zero.", overflowError := "Arithmetic overflow.", livePolite := true, retainFocus := true, submitOnEnter := true, hologramIntent := true, pagesAdapter := true } : CalculatorView)

@[expose] public def calculationCorrect (operation : Operation) (left : Int64) (right : Int64) : Prop := (calculate (operation) (left) (right) = calculate (operation) (left) (right))

public theorem calculate_correct (operation : Operation) (left : Int64) (right : Int64) : calculationCorrect (operation) (left) (right) := by
  rfl

@[expose] public def parseOperation (value : String) : Except (ProtocolError) (Operation) := (if (LexLeanRuntime.equal (value) ("add") : Bool) then Except.ok (Operation.Add) else (if (LexLeanRuntime.equal (value) ("subtract") : Bool) then Except.ok (Operation.Subtract) else (if (LexLeanRuntime.equal (value) ("multiply") : Bool) then Except.ok (Operation.Multiply) else (if (LexLeanRuntime.equal (value) ("divide") : Bool) then Except.ok (Operation.Divide) else Except.error (ProtocolError.UnknownOperation)))))

@[expose] public def decodeRight (operation : Operation) (left : Int64) (rightText : String) : Except (ProtocolError) (Request) := (match (LexLeanRuntime.parseDecimal (rightText) : Option (Int64)) with | Option.none => Except.error (ProtocolError.MalformedRequest) | Option.some right => Except.ok (({ operation := operation, left := left, right := right } : Request)))

@[expose] public def decodeLeft (operation : Operation) (leftText : String) (rightText : String) : Except (ProtocolError) (Request) := (match (LexLeanRuntime.parseDecimal (leftText) : Option (Int64)) with | Option.none => Except.error (ProtocolError.MalformedRequest) | Option.some left => decodeRight (operation) (left) (rightText))

@[expose] public def decodeComplete (version : String) (operationText : String) (leftText : String) (rightText : String) : Except (ProtocolError) (Request) := (if (LexLeanRuntime.equal (version) ("1") : Bool) then (match parseOperation (operationText) with | Except.error error => Except.error (error) | Except.ok operation => decodeLeft (operation) (leftText) (rightText)) else Except.error (ProtocolError.UnsupportedVersion))

@[expose] public def decodeTail4 (version : String) (operationText : String) (leftText : String) (rightText : String) (values : List (String)) : Except (ProtocolError) (Request) := (match values with | List.nil => decodeComplete (version) (operationText) (leftText) (rightText) | List.cons _ _ => Except.error (ProtocolError.MalformedRequest))

@[expose] public def decodeTail3 (version : String) (operationText : String) (leftText : String) (values : List (String)) : Except (ProtocolError) (Request) := (match values with | List.nil => Except.error (ProtocolError.MalformedRequest) | List.cons rightText rest => decodeTail4 (version) (operationText) (leftText) (rightText) (rest))

@[expose] public def decodeTail2 (version : String) (operationText : String) (values : List (String)) : Except (ProtocolError) (Request) := (match values with | List.nil => Except.error (ProtocolError.MalformedRequest) | List.cons leftText rest => decodeTail3 (version) (operationText) (leftText) (rest))

@[expose] public def decodeTail1 (version : String) (values : List (String)) : Except (ProtocolError) (Request) := (match values with | List.nil => Except.error (ProtocolError.MalformedRequest) | List.cons operationText rest => decodeTail2 (version) (operationText) (rest))

@[expose] public def decodeFields (values : List (String)) : Except (ProtocolError) (Request) := (match values with | List.nil => Except.error (ProtocolError.MalformedRequest) | List.cons version rest => decodeTail1 (version) (rest))

@[expose] public def decodeRequest (value : String) : Except (ProtocolError) (Request) := (match (LexLeanRuntime.splitExact (value) ("\t") ((4 : UInt32)) : Option (List (String))) with | Option.none => Except.error (ProtocolError.MalformedRequest) | Option.some fields => decodeFields (fields))

@[expose] public def encodeProtocolError (error : ProtocolError) : String := (match error with | ProtocolError.MalformedRequest => "1\terror\tmalformed-request" | ProtocolError.UnsupportedVersion => "1\terror\tunsupported-version" | ProtocolError.UnknownOperation => "1\terror\tunknown-operation")

@[expose] public def encodeCalculationResult (value : Except (CalculatorError) (Int64)) : String := (match value with | Except.error error => (match error with | CalculatorError.DivisionByZero => "1\terror\tdivision-by-zero" | CalculatorError.Overflow => "1\terror\toverflow") | Except.ok result => (LexLeanRuntime.join (("1\tok\t" :: ((LexLeanRuntime.formatDecimal (result) : String) :: ([] : List (String))))) ("") : String))

@[expose] public def dispatchString (value : String) : String := (match decodeRequest (value) with | Except.error error => encodeProtocolError (error) | Except.ok request => encodeCalculationResult (calculate ((request).operation) ((request).left) ((request).right)))

@[expose] public def dispatchBytes (value : ByteArray) : ByteArray := (match (LexLeanRuntime.utf8Decode (value) : Option (String)) with | Option.none => (LexLeanRuntime.utf8Encode ("1\terror\tmalformed-request") : ByteArray) | Option.some text => (LexLeanRuntime.utf8Encode (dispatchString (text)) : ByteArray))

@[expose] public def calculatorApplication : CalculatorApplication := ({ name := "Calculator", cargoName := "prism-calculator", cargoVersion := "0.1.0", entryRoot := "Calculator.dispatchBytes", coreContract := "hologram:guest/core-wasm@1", requestMaximum := (52 : UInt32), responseMaximum := (27 : UInt32), guestAllocationMaximum := (65536 : UInt32), capabilitiesEmpty := true, fatArchive := true, primaryLayer := (0 : UInt8), viewLayer := (1 : UInt8), view := calculatorView, inputGrammar := InputGrammar.AsciiSignedI64, liveMode := LiveMode.Polite, layout := StyleToken.Compact, color := StyleToken.HighContrast, typography := StyleToken.SystemSans, actions := (ViewAction.Submit :: (ViewAction.Enter :: ([] : List (ViewAction)))), targets := (PresentationTarget.HologramPortable :: (PresentationTarget.GithubPages :: ([] : List (PresentationTarget)))) } : CalculatorApplication)

@[expose] public def checkedResult (value : Option (Int64)) : Except (CalculatorError) (Int64) := (match value with | Option.none => Except.error (CalculatorError.Overflow) | Option.some result => Except.ok (result))

@[expose] public def addExpected (left : Int64) (right : Int64) : Except (CalculatorError) (Int64) := checkedResult ((LexLeanRuntime.checkedAddInt64 (left) (right) : Option (Int64)))

@[expose] public def subtractExpected (left : Int64) (right : Int64) : Except (CalculatorError) (Int64) := checkedResult ((LexLeanRuntime.checkedSubtractInt64 (left) (right) : Option (Int64)))

@[expose] public def multiplyExpected (left : Int64) (right : Int64) : Except (CalculatorError) (Int64) := checkedResult ((LexLeanRuntime.checkedMultiplyInt64 (left) (right) : Option (Int64)))

@[expose] public def divideExpected (left : Int64) (right : Int64) : Except (CalculatorError) (Int64) := (if (LexLeanRuntime.equal (right) ((0 : Int64)) : Bool) then Except.error (CalculatorError.DivisionByZero) else checkedResult ((LexLeanRuntime.checkedQuotientInt64 (left) (right) : Option (Int64))))

public theorem addCorrect (left : Int64) (right : Int64) : (calculate (Operation.Add) (left) (right) = addExpected (left) (right)) := by
  rfl

public theorem subtractCorrect (left : Int64) (right : Int64) : (calculate (Operation.Subtract) (left) (right) = subtractExpected (left) (right)) := by
  rfl

public theorem multiplyCorrect (left : Int64) (right : Int64) : (calculate (Operation.Multiply) (left) (right) = multiplyExpected (left) (right)) := by
  rfl

public theorem divideCorrect (left : Int64) (right : Int64) : (calculate (Operation.Divide) (left) (right) = divideExpected (left) (right)) := by
  rfl

end PrismCalculator.Calculator
